import { useState } from "react";
import { useStudio, type PromptVersion } from "./studioStore";

type Props = {
  /** history key — e.g. `shot:03` or `flow:grid-extract:prompt` */
  storeKey: string;
  /** current editor text, so it can be saved as a manual version */
  current: string;
  currentNegative?: string;
  onRestore: (version: PromptVersion) => void;
  onRerun?: (version: PromptVersion) => void;
  busy?: boolean;
};

export function PromptHistory({
  storeKey,
  current,
  currentNegative,
  onRestore,
  onRerun,
  busy,
}: Props) {
  const { versions, pushVersion, updateVersion, removeVersion } = useStudio();
  const list = versions(storeKey);
  const [openId, setOpenId] = useState<string | null>(null);
  const [draft, setDraft] = useState("");

  const saveManual = () =>
    pushVersion(storeKey, {
      text: current,
      negative: currentNegative,
      source: "manual",
      label: `Manual edit ${new Date().toLocaleTimeString()}`,
    });

  return (
    <div className="ph-wrap">
      <div className="ph-head">
        <span className="sb-lock-label">Prompt history ({list.length})</span>
        <button type="button" className="fl-mini-btn" onClick={saveManual} disabled={!current.trim()}>
          Save current as version
        </button>
      </div>

      {list.length === 0 ? (
        <p className="fl-node-note">
          No versions yet — run the brain or save your manual prompt to start comparing.
        </p>
      ) : (
        <ul className="ph-list">
          {list.map((v) => {
            const editing = openId === v.id;
            return (
              <li key={v.id} className={`ph-item ph-${v.source}`}>
                <div className="ph-item-head">
                  <span className="ph-badge">{v.source}</span>
                  <b className="ph-label">{v.label}</b>
                  <time className="ph-time">{new Date(v.at).toLocaleString()}</time>
                </div>
                {editing ? (
                  <textarea
                    className="fl-prompt"
                    rows={6}
                    value={draft}
                    onChange={(e) => setDraft(e.target.value)}
                  />
                ) : (
                  <p className="ph-text">{v.text}</p>
                )}
                {v.negative && !editing && <p className="ph-neg">NEGATIVE: {v.negative}</p>}
                <div className="ph-actions">
                  {editing ? (
                    <>
                      <button
                        type="button"
                        className="fl-mini-btn"
                        onClick={() => {
                          updateVersion(storeKey, v.id, { text: draft, source: "manual" });
                          setOpenId(null);
                        }}
                      >
                        Save
                      </button>
                      <button type="button" className="fl-mini-btn" onClick={() => setOpenId(null)}>
                        Cancel
                      </button>
                    </>
                  ) : (
                    <>
                      <button
                        type="button"
                        className="fl-mini-btn"
                        onClick={() => {
                          setOpenId(v.id);
                          setDraft(v.text);
                        }}
                      >
                        Edit
                      </button>
                      <button type="button" className="fl-mini-btn" onClick={() => onRestore(v)}>
                        Use in editor
                      </button>
                      {onRerun && (
                        <button
                          type="button"
                          className="fl-mini-btn"
                          disabled={busy}
                          onClick={() => onRerun(v)}
                        >
                          Re-run
                        </button>
                      )}
                      <button
                        type="button"
                        className="fl-mini-btn"
                        onClick={() => removeVersion(storeKey, v.id)}
                      >
                        Delete
                      </button>
                    </>
                  )}
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
