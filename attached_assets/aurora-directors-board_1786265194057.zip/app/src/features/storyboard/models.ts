/**
 * Model registry for the Director's Board.
 *
 * `available: true` models are served by the Lovable AI Gateway and can be
 * selected right away. `available: false` entries (Claude, Grok) are listed so
 * the studio UI shows the full roster, but they need their own provider API key
 * wired in before they can be selected — the gateway does not proxy them.
 */

export type Vendor = "google" | "openai" | "anthropic" | "xai";

export type BrainModel = {
  id: string;
  label: string;
  vendor: Vendor;
  /** true = usable through the Lovable AI Gateway today */
  available: boolean;
  /** which transport the server route must use */
  api: "responses" | "chat";
  hint: string;
};

export const BRAIN_MODELS: BrainModel[] = [
  {
    id: "openai/gpt-5.6-sol",
    label: "GPT-5.6 Sol",
    vendor: "openai",
    available: true,
    api: "responses",
    hint: "Deepest reasoning — best for full flow authoring and shot bibles.",
  },
  {
    id: "openai/gpt-5.6-terra",
    label: "GPT-5.6 Terra",
    vendor: "openai",
    available: true,
    api: "responses",
    hint: "Balanced quality/cost for everyday prompt writing.",
  },
  {
    id: "google/gemini-3.6-flash",
    label: "Gemini 3.6 Flash",
    vendor: "google",
    available: true,
    api: "chat",
    hint: "Fastest brain — great for batch prompt optimisation.",
  },
  {
    id: "google/gemini-3.1-pro-preview",
    label: "Gemini 3.1 Pro",
    vendor: "google",
    available: true,
    api: "chat",
    hint: "Stronger Gemini reasoning when the board gets complex.",
  },
  {
    id: "anthropic/claude",
    label: "Claude (bring your own key)",
    vendor: "anthropic",
    available: false,
    api: "chat",
    hint: "Not proxied by the Lovable AI Gateway — add an ANTHROPIC_API_KEY route to enable.",
  },
  {
    id: "xai/grok",
    label: "Grok (bring your own key)",
    vendor: "xai",
    available: false,
    api: "chat",
    hint: "Not proxied by the Lovable AI Gateway — add an XAI_API_KEY route to enable.",
  },
];

export const DEFAULT_BRAIN_MODEL = "openai/gpt-5.6-sol";

export type VisualModel = {
  id: string;
  label: string;
  kind: "image" | "video";
  available: boolean;
  hint: string;
};

/** Models the "vid agent" (frame + motion generation) can drive. */
export const VID_MODELS: VisualModel[] = [
  {
    id: "google/gemini-3-pro-image",
    label: "Gemini 3 Pro Image",
    kind: "image",
    available: true,
    hint: "Identity-locked stills with reference conditioning. Default frame renderer.",
  },
  {
    id: "openai/gpt-image-2",
    label: "GPT Image 2",
    kind: "image",
    available: true,
    hint: "Crisper typography and graphic detail; no reference images.",
  },
  {
    id: "google/veo-3.1-lite",
    label: "Veo 3.1 Lite",
    kind: "video",
    available: true,
    hint: "Cheapest motion pass — 8s clips with audio.",
  },
  {
    id: "google/veo-3.1-fast",
    label: "Veo 3.1 Fast",
    kind: "video",
    available: true,
    hint: "Higher quality motion at moderate cost.",
  },
  {
    id: "bytedance/seedance-2.5",
    label: "Seedance 2.5 (bring your own key)",
    kind: "video",
    available: false,
    hint: "Not proxied by the Lovable AI Gateway — add a BYTEDANCE_API_KEY route to enable.",
  },
];

export const DEFAULT_VID_MODEL = "google/gemini-3-pro-image";

export const brainModel = (id: string) =>
  BRAIN_MODELS.find((m) => m.id === id) ?? BRAIN_MODELS[0];

export const vidModel = (id: string) => VID_MODELS.find((m) => m.id === id) ?? VID_MODELS[0];

export const AVAILABLE_BRAIN_IDS = BRAIN_MODELS.filter((m) => m.available).map((m) => m.id);
export const AVAILABLE_VID_IDS = VID_MODELS.filter((m) => m.available).map((m) => m.id);
