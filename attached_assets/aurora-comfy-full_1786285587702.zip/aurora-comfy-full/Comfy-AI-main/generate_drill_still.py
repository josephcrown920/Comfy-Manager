from diffusers import StableDiffusionPipeline
import torch

device = "cuda" if torch.cuda.is_available() else "cpu"

pipe = StableDiffusionPipeline.from_pretrained(
    "runwayml/stable-diffusion-v1-5",
    torch_dtype=torch.float16
).to(device)

prompt = "dark drill music video still, cinematic lighting, urban night, smoke"
image = pipe(prompt, seed=12345).images[0]

image.save("frame1.png")
print("✅ Frame generated: frame1.png")
