import { createFileRoute } from "@tanstack/react-router";

const IMAGE_MODELS = ["google/gemini-3-pro-image", "openai/gpt-image-2"] as const;

export const Route = createFileRoute("/api/generate-shot")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { prompt, references, model } = (await request.json()) as {
          prompt?: string;
          references?: string[];
          model?: string;
        };
        if (!prompt || typeof prompt !== "string") {
          return new Response("Missing prompt", { status: 400 });
        }

        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response("Missing LOVABLE_API_KEY", { status: 500 });

        const chosen = (IMAGE_MODELS as readonly string[]).includes(model ?? "")
          ? (model as string)
          : IMAGE_MODELS[0];

        const refs = (Array.isArray(references) ? references : [])
          .filter((r) => typeof r === "string" && r.startsWith("data:image/"))
          .slice(0, 4);

        const payload =
          chosen === "openai/gpt-image-2"
            ? {
                model: chosen,
                prompt,
                quality: "low",
                stream: true,
                partial_images: 1,
              }
            : {
                model: chosen,
                messages: [
                  {
                    role: "user",
                    content: [
                      { type: "text", text: prompt },
                      ...refs.map((url) => ({ type: "image_url", image_url: { url } })),
                    ],
                  },
                ],
                modalities: ["image", "text"],
                stream: true,
              };

        const upstream = await fetch("https://ai.gateway.lovable.dev/v1/images/generations", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${key}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify(payload),
        });

        if (!upstream.ok || !upstream.body) {
          return new Response(await upstream.text(), { status: upstream.status });
        }

        return new Response(upstream.body, {
          headers: {
            "Content-Type": "text/event-stream",
            "Cache-Control": "no-cache",
          },
        });
      },
    },
  },
});
