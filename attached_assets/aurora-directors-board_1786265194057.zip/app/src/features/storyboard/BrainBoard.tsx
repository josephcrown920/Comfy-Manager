import { useEffect, useState } from "react";
import { writeShotPrompts, type BrainShotPrompt } from "./brain";
import { PromptHistory } from "./PromptHistory";
import { useStudio } from "./studioStore";
import { useTimeline } from "./timelineStore";
import { IDENTITY_REFS, loadIdentityReferences } from "./identityRefs";
import { withIdentityLock } from "./characterLock";
import { streamImage } from "@/lib/streamImage";
import type { Shot } from "./shots";

type Row = BrainShotPrompt & { preview?: string; isFinal?: boolean; error?: string };

export function BrainBoard({ onAdd }: { onAdd: (shot: Shot) => void }) {
  const { shots } = useTimeline();
  const { seed, setSeed, randomizeSeed, seedLine, pushVersion } = useStudio();
  const [rows, setRows] = useState<Row[]>([]);
  const [busy, setBusy] = useState(false);
  const [running, setRunning] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setRows((prev) => prev.filter((r) => shots.some((s) => s.id === r.id)));
  }, [shots]);

  const write = async () => {
    if (busy) return;
    setBusy(true);
    setError(null);
    try {
      const res = await writeShotPrompts({
        seed,
        shots: shots.map((s) => ({
          id: s.id,
          title: s.title,
          frame: s.frame,
          wardrobe: s.wardrobe,
          mood: s.mood,
          note: s.note,
        })),
      });
      setRows(res.shots);
      res.shots.forEach((s) =>
        pushVersion(`shot:${s.id}`, {
          text: s.prompt,
          negative: s.negative,
          source: "brain",
          label: `Brain · ${s.camera}`,
        }),
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : "Brain call failed");
    } finally {
      setBusy(false);
    }
  };

  const patch = (id: string, p: Partial<Row>) =>
    setRows((prev) => prev.map((r) => (r.id === id ? { ...r, ...p } : r)));

  const generate = async (row: Row, promptText = row.prompt) => {
    if (running) return;
    setRunning(row.id);
    patch(row.id, { preview: undefined, isFinal: false, error: undefined });
    try {
      const references = await loadIdentityReferences(IDENTITY_REFS.map((r) => r.url));
      const full = [withIdentityLock(promptText, "strict", references.length), seedLine(), row.negative]
        .filter(Boolean)
        .join("\n\n");
      await streamImage(
        "/api/generate-shot",
        full,
        (dataUrl, isFinal) => patch(row.id, { preview: dataUrl, isFinal }),
        references,
      );
    } catch (err) {
      patch(row.id, { error: err instanceof Error ? err.message : "Generation failed" });
    } finally {
      setRunning(null);
    }
  };

  const addToDeck = (row: Row) => {
    if (!row.preview) return;
    const shot: Shot = {
      id: `B${Date.now().toString().slice(-5)}`,
      title: row.title,
      type: "brain-written",
      image: row.preview,
      alt: row.title,
      frame: row.camera,
      wardrobe: "Locked wardrobe",
      mood: row.continuity,
      note: row.prompt.slice(0, 220),
      variants: [
        { image: row.preview, label: "Brain", frame: row.camera, wardrobe: "Locked wardrobe" },
      ],
    };
    onAdd(shot);
  };

  return (
    <section className="fl-wrap" aria-label="Brain layer">
      <div className="mb-head">
        <h2 className="pv-title">Brain · gpt-5.6-sol</h2>
        <p className="pv-sub">
          Writes an identity-locked prompt plus negative constraints for every shot in the deck, from
          your locked references. Edit anything, compare versions, and re-run the render.
        </p>
      </div>

      <SeedBar seed={seed} setSeed={setSeed} randomize={randomizeSeed} />

      <div className="fl-panel-actions" style={{ marginBottom: "0.9rem" }}>
        <button type="button" className="pv-btn pv-btn-primary" onClick={write} disabled={busy}>
          {busy ? "Writing prompts…" : `✦ Write prompts for all ${shots.length} shots`}
        </button>
      </div>
      {error && <p className="fl-error">{error}</p>}

      <div className="brain-grid">
        {rows.map((row) => (
          <article key={row.id} className="brain-card">
            <header className="brain-card-head">
              <span className="sb-pill">Shot {row.id}</span>
              <b>{row.title}</b>
              <em className="fl-node-note">{row.camera}</em>
            </header>

            <textarea
              className="fl-prompt"
              rows={7}
              value={row.prompt}
              onChange={(e) => patch(row.id, { prompt: e.target.value })}
            />
            <textarea
              className="fl-prompt"
              rows={3}
              value={row.negative}
              onChange={(e) => patch(row.id, { negative: e.target.value })}
            />
            <p className="fl-node-note">Continuity: {row.continuity}</p>

            <div className="ph-actions">
              <button
                type="button"
                className="pv-btn"
                disabled={running !== null}
                onClick={() => generate(row)}
              >
                {running === row.id ? "Rendering…" : "▶ Generate frame"}
              </button>
              {row.preview && row.isFinal && (
                <button type="button" className="pv-btn" onClick={() => addToDeck(row)}>
                  Add to deck
                </button>
              )}
            </div>

            {row.error && <p className="fl-error">{row.error}</p>}
            {row.preview && (
              <img
                className={row.isFinal ? "fl-result-img" : "fl-result-img fl-blur"}
                src={row.preview}
                alt={row.title}
              />
            )}

            <PromptHistory
              storeKey={`shot:${row.id}`}
              current={row.prompt}
              currentNegative={row.negative}
              busy={running !== null}
              onRestore={(v) => patch(row.id, { prompt: v.text, negative: v.negative ?? row.negative })}
              onRerun={(v) => generate(row, v.text)}
            />
          </article>
        ))}
      </div>
    </section>
  );
}

export function SeedBar({
  seed,
  setSeed,
  randomize,
}: {
  seed: number | null;
  setSeed: (s: number | null) => void;
  randomize: () => void;
}) {
  return (
    <div className="sb-lockbar">
      <div className="sb-lock-col">
        <span className="sb-lock-label">Seed vision</span>
        <div className="ph-actions">
          <input
            className="sb-input"
            style={{ maxWidth: "10rem" }}
            type="number"
            value={seed ?? ""}
            placeholder="off"
            onChange={(e) => setSeed(e.target.value === "" ? null : Number(e.target.value))}
          />
          <button type="button" className="fl-mini-btn" onClick={randomize}>
            Randomize
          </button>
          <button type="button" className="fl-mini-btn" onClick={() => setSeed(null)}>
            Off
          </button>
        </div>
        <p className="fl-node-note">
          Locks the grade, grain and lens character across every frame rendered on this board.
        </p>
      </div>
    </div>
  );
}
