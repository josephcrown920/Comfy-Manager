/**
 * Consistency lock — every generated frame reuses this exact character,
 * wardrobe language and palette so new shots match the existing deck.
 */

export const CHARACTER_LOCK = [
  "SUBJECT (must stay identical in every frame):",
  "A Black male recording artist in his late twenties, lean athletic build, warm deep-brown skin,",
  "long shoulder-length crimson-red dreadlocks with darker roots, thin goatee,",
  "sculpted wraparound red sunglasses with amber-yellow lenses,",
  "a single large diamond stud earring and layered iced-out cuban-link diamond chains.",
  "Same face structure, same jawline, same hair length and colour in every frame.",
].join(" ");

export const STYLE_LOCK = [
  "STYLE LOCK: cinematic music-video still, anamorphic 35mm look, shallow depth of field,",
  "rich film grain, deep contrast, practical neon sources.",
  "Palette restricted to neon red, royal blue, hot pink and gold highlights against near-black shadows.",
  "Photoreal, no text, no watermark, no logos, 16:9 framing.",
].join(" ");

export type Preset = {
  id: string;
  label: string;
  hint: string;
  scene: string;
};

export const PRESETS: Preset[] = [
  {
    id: "miami",
    label: "Miami Neon Night",
    hint: "Wet asphalt, hotel signage, convertible",
    scene:
      "Rainy Ocean Drive at night, red convertible, glowing art-deco hotel signage, wet reflective asphalt, humid neon haze.",
  },
  {
    id: "studio",
    label: "Blue Neon Studio",
    hint: "Tube lights, sparkle leather",
    scene:
      "Seamless royal-blue studio backdrop with vertical neon tube lights, sparkle-flecked black leather jacket, hard rim light.",
  },
  {
    id: "street",
    label: "Street Grit",
    hint: "Alley, subway, crosswalk",
    scene:
      "Gritty city exterior at dusk — back alley steam, subway platform or crosswalk — glossy hooded puffer jacket, handheld documentary energy.",
  },
  {
    id: "stage",
    label: "Performance Stage",
    hint: "Vintage mic, haze, spotlights",
    scene:
      "Live performance set, vintage ribbon microphone, hot-pink wash and stage haze, sweat-lit close performance energy.",
  },
  {
    id: "fashion",
    label: "Fashion Editorial",
    hint: "Clean seamless, wardrobe hero",
    scene:
      "High-fashion editorial setup, clean seamless backdrop, sculpted key light, wardrobe and jewellery as the hero of the frame.",
  },
];

export const CAMERAS = [
  "Extreme close-up",
  "Tight profile portrait",
  "Medium chest-up",
  "Low-angle hero shot",
  "Wide establishing shot",
  "Over-the-shoulder tracking",
] as const;

/** Hard continuity rules — restated in every prompt so nothing drifts shot to shot. */
export const CONTINUITY_LOCK = [
  "IDENTITY CONTINUITY (non-negotiable):",
  "1. Treat the attached reference frames as the ground truth for this person.",
  "2. Reproduce the exact same face: same skin tone, same nose and lip shape, same jawline, same goatee density.",
  "3. Hair must stay shoulder-length crimson-red locs with darker roots — never shorter, never a different colour.",
  "4. Eyewear must stay the same sculpted wraparound red frames with amber-yellow lenses.",
  "5. Jewellery must stay: one large diamond stud earring plus layered iced cuban-link chains.",
  "6. Age, build and proportions stay identical; only scene, wardrobe and camera angle may change.",
].join(" ");

export const NEGATIVE_LOCK = [
  "DO NOT: change the person's ethnicity, age or face; swap in a different model;",
  "shorten, restyle or recolour the hair; remove or restyle the red sunglasses;",
  "remove the earring or chains; add tattoos, facial hair changes or scars not in the references;",
  "add text, captions, watermarks, logos or extra people.",
].join(" ");

export type LockLevel = "strict" | "balanced" | "loose";

const LEVEL_LINE: Record<LockLevel, string> = {
  strict:
    "MATCH STRENGTH: maximum. The face must be indistinguishable from the reference frames — treat any deviation as a failed render.",
  balanced:
    "MATCH STRENGTH: high. Keep the face, hair and eyewear identical to the references; wardrobe and environment may change freely.",
  loose:
    "MATCH STRENGTH: moderate. Clearly the same person and signature look, with room for stylistic interpretation.",
};

export function buildPrompt(input: {
  idea: string;
  scene: string;
  camera: string;
  lock?: LockLevel;
  refCount?: number;
}) {
  const lock = input.lock ?? "strict";
  return [
    CHARACTER_LOCK,
    CONTINUITY_LOCK,
    input.refCount
      ? `REFERENCES: ${input.refCount} attached image(s) of this exact person. Match them.`
      : "",
    `SCENE: ${input.scene}`,
    `CAMERA: ${input.camera}.`,
    `DIRECTION: ${input.idea}`,
    STYLE_LOCK,
    LEVEL_LINE[lock],
    NEGATIVE_LOCK,
  ]
    .filter(Boolean)
    .join("\n\n");
}

/** Wraps any prompt (e.g. a flow prompt) with the identity + negative locks. */
export function withIdentityLock(prompt: string, lock: LockLevel = "strict", refCount = 0) {
  return [
    CHARACTER_LOCK,
    CONTINUITY_LOCK,
    refCount ? `REFERENCES: ${refCount} attached image(s) of this exact person. Match them.` : "",
    prompt,
    STYLE_LOCK,
    LEVEL_LINE[lock],
    NEGATIVE_LOCK,
  ]
    .filter(Boolean)
    .join("\n\n");
}
