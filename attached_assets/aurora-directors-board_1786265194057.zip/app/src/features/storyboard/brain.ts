/** Client helpers for the openai/gpt-5.6-sol "brain" layer. */

import { CHARACTER_LOCK, CONTINUITY_LOCK, NEGATIVE_LOCK, STYLE_LOCK } from "./characterLock";
import { IDENTITY_REFS } from "./identityRefs";

export type BrainShotPrompt = {
  id: string;
  title: string;
  camera: string;
  prompt: string;
  negative: string;
  continuity: string;
};

export type BrainFlowNode = { id: string; text: string; rows: string[] | null };

export type BrainSetup = {
  id: string;
  label: string;
  scene: string;
  camera: string;
  wardrobe: string;
  continuity: string;
  prompt: string;
};

const LOCKS = {
  character: CHARACTER_LOCK,
  continuity: CONTINUITY_LOCK,
  style: STYLE_LOCK,
  negative: NEGATIVE_LOCK,
  identityReferences: IDENTITY_REFS.map((r) => ({ id: r.id, label: r.label })),
};

/** Active reasoning model — set from the admin panel via the studio store. */
let activeBrainModel = "openai/gpt-5.6-sol";

export function configureBrain(modelId: string) {
  if (modelId) activeBrainModel = modelId;
}

export function currentBrainModel() {
  return activeBrainModel;
}

async function callBrain<T>(task: string, input: unknown): Promise<T> {
  const res = await fetch("/api/brain", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      task,
      model: activeBrainModel,
      input: { locks: LOCKS, ...(input as object) },
    }),
  });
  if (!res.ok) {
    const detail = await res.text().catch(() => "");
    if (res.status === 429) throw new Error("Rate limited — wait a moment and try again.");
    if (res.status === 402) throw new Error("AI credits exhausted — top up to keep generating.");
    throw new Error(detail || `Brain call failed (${res.status})`);
  }
  return (await res.json()) as T;
}


export function writeShotPrompts(input: {
  shots: { id: string; title: string; frame: string; wardrobe: string; mood: string; note: string }[];
  seed?: number | null;
}) {
  return callBrain<{ shots: BrainShotPrompt[] }>("shot-prompts", {
    ...input,
    instruction:
      "Write one identity-locked image prompt and a matching negative-constraint line for EVERY shot supplied. Keep each shot's existing scene and wardrobe intent, but sharpen it into a render-ready prompt. Add a one-line continuity note describing what must not drift from the previous shot.",
  });
}

export function fillFlowNodes(input: {
  flow: { id: string; label: string; blurb: string; outcome: string };
  nodes: { id: string; kind: string; title: string; text?: string; rows?: string[] }[];
  deck: { id: string; title: string; frame: string; wardrobe: string; mood: string }[];
  timing: { id: string; start: number; end: number; section?: string }[];
  audioName: string;
  seed?: number | null;
}) {
  return callBrain<{ nodes: BrainFlowNode[] }>("flow-fill", {
    ...input,
    instruction:
      "Auto-populate every node in this flow using the deck's current order and audio timestamps. Prompt/model nodes get full render-ready prompt text referencing the beat they cover (mention the timecode range). Iterator nodes get one row per variation, matching the number of existing rows when present, otherwise 4. Nodes with no text return an empty string and null rows.",
  });
}

export function expandMoodboard(input: {
  deck: { id: string; title: string; frame: string; wardrobe: string; mood: string; note: string }[];
  count?: number;
  seed?: number | null;
}) {
  return callBrain<{ setups: BrainSetup[] }>("moodboard-expand", {
    count: 4,
    ...input,
    instruction:
      "Invent brand-new setups that do NOT duplicate anything already in the deck. Each setup needs a short label, a scene description, a suggested camera angle, a wardrobe call, a continuity note, and a full render-ready prompt.",
  });
}
