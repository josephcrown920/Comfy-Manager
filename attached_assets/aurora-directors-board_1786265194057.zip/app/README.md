# Director's Board — Storyboard Studio

AI music-video storyboard studio: identity-locked shot deck, infinite canvas, character
reference sheets, flow-based prompt optimizer, sequencer and video preview.

Stack: TanStack Start (React 19 + Vite 7) · Tailwind v4 · Lovable AI Gateway.

## Views

| Tab | What it does |
| --- | --- |
| Shot Deck | The reference frames; click a tile for the full shot card |
| Canvas | Infinite node workspace — character sheet → prompt → frame/video nodes with curved links |
| Character Sheet | Eight identity-locked turnaround angles rendered from the reference frames |
| Moodboard / Brain / Flows | Prompt authoring + brain-assisted optimization |
| AI Generate | Single-shot renderer |
| Sequencer / Preview | Timing against audio and playback |
| Admin | Swap front-page photos, pick the brain + vid-agent models |

## Admin settings

Open the **Admin** tab:

- **Front page photos** — upload a file or paste a URL to replace any deck frame. Overrides are
  stored per browser (localStorage, key `storyboard.studio.v1`) and apply across deck, canvas,
  character sheet and sequencer. "Revert" or "Reset all photos" restores the shipped images.
- **Agent models** — choose the brain (reasoning) and vid agent (frames/motion). Selections are
  sent with every `/api/brain` and `/api/generate-shot` call.

## Models

Brains: `openai/gpt-5.6-sol`, `openai/gpt-5.6-terra`, `google/gemini-3.6-flash`,
`google/gemini-3.1-pro-preview`. Claude and Grok are listed but disabled — they are not proxied by
the gateway; enable them by adding your own provider key and a branch in `src/routes/api/brain.ts`.

Vid agents: `google/gemini-3-pro-image`, `openai/gpt-image-2` (frames) and `google/veo-3.1-lite`
(motion).

Server routes: `src/routes/api/brain.ts` (JSON reasoning; OpenAI models use `/v1/responses`,
Google models use `/v1/chat/completions`) and `src/routes/api/generate-shot.ts` (streaming
`/v1/images/generations`).

## Local development

```sh
npm install
npm run dev       # http://localhost:8080
npm run build
```

Requires `LOVABLE_API_KEY` in the environment for any AI call.

## Running on Replit

1. **Import** — Replit → *Create App* → *Import from GitHub* (or upload the exported zip and unzip
   it in the workspace root).
2. **Language** — pick the **Node.js** template if asked. Node 20+.
3. **Secrets** — Tools → *Secrets*, add:
   - `LOVABLE_API_KEY` = your Lovable AI Gateway key (required for Brain, Canvas renders,
     Character Sheet and AI Generate).
4. **`.replit`** — create/replace with:

   ```toml
   run = "npm run dev"
   entrypoint = "src/routes/index.tsx"

   [nix]
   channel = "stable-24_05"

   [[ports]]
   localPort = 8080
   externalPort = 80

   [env]
   HOST = "0.0.0.0"
   PORT = "8080"
   ```
5. **Install & run** — in the Shell: `npm install`, then press **Run**. Open the webview; Vite must
   bind `0.0.0.0:8080` for Replit to proxy it (already handled by the `HOST`/`PORT` env above).
6. **Production** — `npm run build` then serve the build output with `npm run start` (Replit
   Deployments → *Autoscale*, run command `npm run build && npm run start`).

### Embedding it in an existing app instead

The studio is self-contained under `src/features/storyboard/`:

```tsx
import { StoryboardGallery } from "@/features/storyboard/StoryboardGallery";

<StoryboardGallery title="My Video" showHero />
```

Copy these into your app:

- `src/features/storyboard/**` (all boards, stores, locks, models registry)
- `src/routes/api/brain.ts` and `src/routes/api/generate-shot.ts` (or port them to your backend —
  they are plain `fetch` proxies to `https://ai.gateway.lovable.dev`)
- `src/lib/streamImage.ts` (SSE image stream parser)
- the storyboard CSS blocks at the end of `src/styles.css` plus the Glass Aurora tokens
- the Bebas Neue + Barlow `<link>` tags from `src/routes/__root.tsx`

Peer deps: `react`, `react-dom`, `eventsource-parser`.

## Troubleshooting

- **"Missing LOVABLE_API_KEY"** — secret not set or the process wasn't restarted.
- **429 / 402** — gateway rate limit or exhausted credits.
- **Blank webview on Replit** — the dev server bound to `127.0.0.1`; set `HOST=0.0.0.0`.

## Aurora Studio (`/studio`)

The Director's Board (`/`) and the Aurora node studio are now one app.

- `/` — the Director's Board: shot deck, canvas, character sheet, flows, brain, admin.
  The header has an **Open Aurora Studio →** link.
- `/studio` — the Aurora flow studio: draggable shot-node canvas, inspector, timeline,
  characters panel, Director chat (streaming tool calls), GPU worker panel and **Export ZIP**.

### Files that came with the studio

- `src/features/storyboard/studio/**` — StudioPage, FlowCanvas, Inspector, Timeline,
  CharactersPanel, DirectorChat, VideoAgentPanel, WorkersPanel
- `src/lib/board-store.ts` — the studio board (localStorage, seeded from `shots.ts`)
- `src/lib/export-zip.ts` — client-side ZIP export (`fflate`)
- `src/lib/render-jobs.ts` — render queue client (`render_jobs`, `gpu_workers`)
- `src/lib/ai-gateway.server.ts`, `src/routes/api/chat.ts` — Director chat via the AI gateway
- `src/routes/api/generate-image.ts` — plain image stream (the board still uses
  `/api/generate-shot` for identity-locked renders)
- `src/routes/api/public/gpu/{register,claim,complete}.ts` — GPU worker HTTP API
- `cli/aurora-worker.mjs` — the worker you run on your own GPU box

Extra deps: `ai`, `@ai-sdk/react`, `@ai-sdk/openai-compatible`, `react-markdown`, `fflate`.

### Running a GPU worker

```bash
node cli/aurora-worker.mjs --api https://your-app.lovable.app \
  --name my-4090 --gpu "RTX 4090" --models seedance-2.5,ltx-video --run ./render.sh
```

The worker registers itself, claims queued jobs, and posts the output URL back. Jobs live in
the backend `render_jobs` table; workers in `gpu_workers`. Both are readable by the studio
UI, but only the render service can claim jobs or write results.
