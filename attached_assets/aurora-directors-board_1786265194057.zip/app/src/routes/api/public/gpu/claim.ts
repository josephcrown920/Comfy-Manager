import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";

const Body = z.object({
  worker_id: z.string().uuid(),
  models: z.array(z.string().max(80)).max(20).default([]),
});

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "content-type, apikey",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

export const Route = createFileRoute("/api/public/gpu/claim")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: cors }),
      POST: async ({ request }) => {
        const parsed = Body.safeParse(await request.json().catch(() => null));
        if (!parsed.success) {
          return Response.json({ error: "Invalid body" }, { status: 400, headers: cors });
        }
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
        // Generated DB types are refreshed out-of-band; cast at the boundary.
        const db = supabaseAdmin as unknown as { from: (t: string) => any };

        await db.from("gpu_workers")
          .update({ last_seen_at: new Date().toISOString(), status: "online" })
          .eq("id", parsed.data.worker_id);

        let pending = db.from("render_jobs")
          .select("*")
          .eq("status", "queued")
          .order("created_at", { ascending: true })
          .limit(1);
        if (parsed.data.models.length) pending = pending.in("model", parsed.data.models);

        const { data: jobs, error } = await pending;
        if (error) return Response.json({ error: error.message }, { status: 500, headers: cors });
        const job = jobs?.[0];
        if (!job) return Response.json({ job: null }, { headers: cors });

        const { data: claimed } = await db.from("render_jobs")
          .update({ status: "running", worker_id: parsed.data.worker_id })
          .eq("id", job.id)
          .eq("status", "queued")
          .select()
          .maybeSingle();

        return Response.json({ job: claimed ?? null }, { headers: cors });
      },
    },
  },
});