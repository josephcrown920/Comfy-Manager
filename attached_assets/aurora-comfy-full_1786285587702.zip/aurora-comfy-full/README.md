# Aurora Comfy Full Bundle

Everything for the ComfyUI + free-GPU stack, including the latest fixes.

## Contents
- `Comfy-AI-main/` — the Core Engine deployment app (full source)
- `ComfyUI-Manager-main.zip` — ComfyUI Manager (extract into ComfyUI/custom_nodes/)
- `workers/kaggle/`, `workers/colab/` — free-GPU worker notebooks + launchers + READMEs
- `workers/comfyui/` — ComfyUI swarm worker launcher + support files
- `notebooks/` — hybrid inference Colab notebook
- `aurora-fixes/` — the latest Aurora source changes:
  - ComfyUI Studio backend client (`src/lib/comfy-studio.server.ts`)
  - Comfy server functions incl. Studio status/run/poll (`src/lib/comfy.functions.ts`)
  - Comfy core + default workflow graphs
  - `/comfy` page with the Studio panel, ComfyUI admin page, and the new Admin → GPU launch page
  - Supabase migrations for comfy_workflows/comfy_runs + Studio columns
- `docs/` — swarm architecture notes

## Secrets needed at runtime (never stored in this ZIP)
NGROK_AUTHTOKEN, NGROK_STATIC_DOMAIN, AURORA_URL, AURORA_REGISTER_SECRET
(optional: AURORA_WORKER_TOKEN, AURORA_TASKS, COMFY_STUDIO_URL)

See workers/kaggle/README.md and workers/colab/README.md for step-by-step launch guides.
