# ComfyUI free-GPU worker swarm

## What & Why
Let Aurora run a **swarm of free-tier GPU workers** (Kaggle + Google Colab) that run **ComfyUI** and auto-join the orchestrator. ComfyUI is already a first-class protocol in Aurora and its adapter already advertises `image`, `video`, `lipsync`, `motion` and dispatches any workflow graph — but today the only free-GPU templates run a different `custom` FastAPI worker (lipsync/motion only), there are no default ComfyUI graphs for **text-to-image** or **text/image-to-video**, and there's no easy way to launch and watch many workers at once. This task makes ComfyUI launchable on free GPUs as a fleet that spreads jobs across all online sessions, with external providers staying as fallback.

Scope confirmed with the user: capabilities = **image (new), video (new), motion (existing), lip-sync (existing)**; providers = **both Kaggle and Colab**.

## Done looks like
- A user can open a provided notebook on **Kaggle** or **Colab**, run it, and within minutes a ComfyUI worker appears in **Admin → Workers** as `protocol: comfyui` with the capabilities its GPU can serve — no manual registration.
- Launching the notebook on several sessions/accounts produces **multiple** workers; Aurora spreads jobs across them (least-loaded first) and never dispatches to a full or offline/timed-out session.
- **Image** (text-to-image, SDXL/Flux) and **video** (text/image-to-video) generations route to an online ComfyUI swarm worker first, falling back to existing external providers only when no capable worker is online. **Lip-sync** and **motion** continue to work and now also run on swarm workers.
- Admin shows a live fleet view: per-worker protocol, capabilities, in-flight vs max concurrency, health/last heartbeat, and pause/remove controls, plus total available swarm capacity.
- "Start application" runs clean and `bun test src/` stays green; new workflow-builder and routing logic are covered by tests.

## Out of scope / guardrails
- We do NOT keep free GPUs running 24/7 — free tiers time out (Kaggle ~12h/session and weekly quota; Colab idle-disconnects). Relaunching sessions is the user's job; the notebook just re-registers cleanly on each boot.
- No paid providers and no new external image/video APIs in this task (Replicate/Kling/etc. remain only as fallback).
- Follow the existing "explicit failure, no silent fallback" rule: for self-hosted-only paths, when no capable worker is online show the clear "register/launch a GPU worker" error rather than silently switching backends.
- Adding capabilities must NOT bypass credits — image/video must charge through the existing pricing path like other kinds.

## Steps
1. **ComfyUI image + video workflow graphs** — Add default ComfyUI prompt-graph builders for text-to-image (SDXL/Flux) and text/image-to-video, mirroring the existing lip-sync and motion graph builders, with per-node input patching (prompt, negative, seed, steps, width/height, input image/URL, frame count). Ship reference workflow JSON exports alongside the existing ones in `workers/comfyui/` and document the required custom-node class names.

2. **Route image/video jobs to swarm workers** — In the orchestrator's `gpuWorker` adapter, pick the correct workflow builder by `kind` (image/video/lipsync/motion) and pass it as the `comfyWorkflow` to the ComfyUI provider. Ensure the candidate-model/sentinel wiring lets image and video reach the adapter (see the candidate-model sentinel constraint — a kind needs at least a sentinel model or it never reaches its adapter), and that capability matching includes `image`/`video`. Keep external providers as fallback for image/video; keep lip-sync/motion self-hosted-only with explicit failure.

3. **Free-GPU ComfyUI launch notebooks (Kaggle + Colab)** — Create two launchable notebooks/templates that: install ComfyUI + the required custom nodes (LatentSync, MimicMotion, URL loaders + VideoHelperSuite) + the image/video model nodes, fetch weights, start ComfyUI on `:8188` listening on all interfaces, open a stable **ngrok** tunnel, **health-gate** before registering, and **auto-register** as `protocol: comfyui` advertising only the capabilities the session's GPU/VRAM can actually serve. Reuse the existing register/health contract and secret conventions (`AURORA_URL`, `AURORA_REGISTER_KEY`, `NGROK_AUTHTOKEN`, `NGROK_STATIC_DOMAIN`). Mirror the existing Kaggle bootstrap quirks (Kaggle Secrets are not env vars; advertise only installed caps; pass `/health` before registering).

4. **Swarm fan-out + dedup + liveness** — Make many concurrent workers safe: a restarted/relaunched session must update its existing worker row rather than create a duplicate (stable worker identity), the orchestrator spreads jobs across the fleet using the existing in-flight-ascending least-loaded selection and `max_concurrency` skip, and the scheduled health check pauses/skips stale tunnels (free-tier timeouts) so no job dispatches to a dead session.

5. **Admin swarm dashboard** — Extend the Admin → Workers view into a fleet dashboard: list every worker with protocol, capabilities, in-flight/max-concurrency, health and last heartbeat, with pause/resume/remove controls and an aggregate "available swarm capacity per capability" summary.

6. **Docs** — Update `workers/README.md` and `workers/comfyui/README.md` with the free-GPU swarm recipes for Kaggle and Colab: required secrets, capability/VRAM guidance (which GPUs can serve image vs video vs motion), and how to scale by launching more sessions.

## Relevant files
- `src/lib/inference/providers/comfyui.ts`
- `src/lib/inference/protocols.ts`
- `src/lib/orchestrator.server.ts:975-1000,1208-1300,1291-1470,1551`
- `src/lib/lipsync-workflows.server.ts`
- `src/lib/motion-workflows.server.ts`
- `src/lib/gpu-worker-health.ts`
- `src/lib/workers.functions.ts`
- `src/routes/api/public/workers/register.ts`
- `src/routes/api/public/workers/health.ts`
- `src/routes/admin.tsx`
- `src/routes/admin.comfy.tsx`
- `src/routes/admin.orchestration.tsx`
- `workers/comfyui/README.md`
- `workers/comfyui/latentsync-lipsync.workflow.json`
- `workers/comfyui/mimicmotion-motion.workflow.json`
- `workers/kaggle/aurora_worker_kaggle.py`
- `workers/README.md`
- `notebooks/hybrid_ai_inference_colab.ipynb`
- `supabase/migrations/20260625210825_gpu_workers_protocol.sql`
