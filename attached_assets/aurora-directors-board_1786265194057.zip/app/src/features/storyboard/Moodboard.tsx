import { useState } from "react";
import { CHARACTER_LOCK, STYLE_LOCK, CONTINUITY_LOCK, NEGATIVE_LOCK, withIdentityLock } from "./characterLock";
import { IDENTITY_REFS, loadIdentityReferences } from "./identityRefs";
import { expandMoodboard, type BrainSetup } from "./brain";
import { useStudio } from "./studioStore";
import { streamImage } from "@/lib/streamImage";
import { SeedBar } from "./BrainBoard";
import type { Shot } from "./shots";

const PALETTE = [
  { name: "Neon Red", hex: "#ff2f56" },
  { name: "Royal Blue", hex: "#2445ff" },
  { name: "Hot Pink", hex: "#ff4fa3" },
  { name: "Gold", hex: "#ffc247" },
  { name: "Near Black", hex: "#08070b" },
];

export function Moodboard({ shots, onAdd }: { shots: Shot[]; onAdd?: (shot: Shot) => void }) {
  const wardrobe = Array.from(new Set(shots.flatMap((s) => s.variants.map((v) => v.wardrobe))));
  const refs = shots.slice(0, 8);
  const { seed, setSeed, randomizeSeed, seedLine, pushVersion } = useStudio();
  const [setups, setSetups] = useState<
    (BrainSetup & { preview?: string; isFinal?: boolean; error?: string })[]
  >([]);
  const [busy, setBusy] = useState(false);
  const [running, setRunning] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const expand = async () => {
    if (busy) return;
    setBusy(true);
    setError(null);
    try {
      const res = await expandMoodboard({
        seed,
        deck: shots.map((s) => ({
          id: s.id,
          title: s.title,
          frame: s.frame,
          wardrobe: s.wardrobe,
          mood: s.mood,
          note: s.note,
        })),
      });
      setSetups(res.setups);
      res.setups.forEach((s) =>
        pushVersion(`setup:${s.id}`, {
          text: s.prompt,
          source: "brain",
          label: `Setup · ${s.label}`,
        }),
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : "Moodboard expansion failed");
    } finally {
      setBusy(false);
    }
  };

  const renderSetup = async (id: string) => {
    const setup = setups.find((s) => s.id === id);
    if (!setup || running) return;
    setRunning(id);
    const patch = (p: Partial<BrainSetup & { preview: string; isFinal: boolean; error: string }>) =>
      setSetups((prev) => prev.map((s) => (s.id === id ? { ...s, ...p } : s)));
    patch({ preview: undefined, isFinal: false, error: undefined });
    try {
      const references = await loadIdentityReferences(IDENTITY_REFS.map((r) => r.url));
      const prompt = [withIdentityLock(setup.prompt, "strict", references.length), seedLine()]
        .filter(Boolean)
        .join("\n\n");
      await streamImage(
        "/api/generate-shot",
        prompt,
        (dataUrl, isFinal) => patch({ preview: dataUrl, isFinal }),
        references,
      );
    } catch (err) {
      patch({ error: err instanceof Error ? err.message : "Render failed" });
    } finally {
      setRunning(null);
    }
  };

  const addSetup = (setup: BrainSetup & { preview?: string }) => {
    if (!setup.preview || !onAdd) return;
    onAdd({
      id: `M${Date.now().toString().slice(-5)}`,
      title: setup.label,
      type: "moodboard expansion",
      image: setup.preview,
      alt: setup.label,
      frame: setup.camera,
      wardrobe: setup.wardrobe,
      mood: setup.continuity,
      note: setup.scene,
      variants: [
        { image: setup.preview, label: "Setup", frame: setup.camera, wardrobe: setup.wardrobe },
      ],
    });
  };

  return (
    <section className="mb-wrap" aria-label="Moodboard">
      <div className="mb-head">
        <h2 className="pv-title">Moodboard</h2>
        <p className="pv-sub">
          Every flow reads from this board — character, palette and wardrobe are injected into each prompt automatically.
        </p>
      </div>

      <SeedBar seed={seed} setSeed={setSeed} randomize={randomizeSeed} />

      <div className="fl-panel-actions" style={{ marginBottom: "0.9rem" }}>
        <button type="button" className="pv-btn pv-btn-primary" onClick={expand} disabled={busy}>
          {busy ? "Expanding…" : "✦ Expand moodboard with gpt-5.6-sol"}
        </button>
      </div>
      {error && <p className="fl-error">{error}</p>}

      {setups.length > 0 && (
        <div className="brain-grid" style={{ marginBottom: "1.2rem" }}>
          {setups.map((s) => (
            <article key={s.id} className="brain-card">
              <header className="brain-card-head">
                <span className="sb-pill">New setup</span>
                <b>{s.label}</b>
                <em className="fl-node-note">{s.camera}</em>
              </header>
              <p className="mb-lock">{s.scene}</p>
              <p className="fl-node-note">Wardrobe: {s.wardrobe}</p>
              <p className="fl-node-note">Continuity: {s.continuity}</p>
              <textarea
                className="fl-prompt"
                rows={6}
                value={s.prompt}
                onChange={(e) =>
                  setSetups((prev) =>
                    prev.map((x) => (x.id === s.id ? { ...x, prompt: e.target.value } : x)),
                  )
                }
              />
              <div className="ph-actions">
                <button
                  type="button"
                  className="pv-btn"
                  disabled={running !== null}
                  onClick={() => renderSetup(s.id)}
                >
                  {running === s.id ? "Rendering…" : "▶ Render setup"}
                </button>
                {s.preview && s.isFinal && onAdd && (
                  <button type="button" className="pv-btn" onClick={() => addSetup(s)}>
                    Add to deck
                  </button>
                )}
              </div>
              {s.error && <p className="fl-error">{s.error}</p>}
              {s.preview && (
                <img
                  className={s.isFinal ? "fl-result-img" : "fl-result-img fl-blur"}
                  src={s.preview}
                  alt={s.label}
                />
              )}
            </article>
          ))}
        </div>
      )}


      <div className="mb-grid">
        <article className="mb-card">
          <h3 className="mb-card-title">Character lock</h3>
          <p className="mb-lock">{CHARACTER_LOCK}</p>
          <p className="mb-lock mb-lock-note">{CONTINUITY_LOCK}</p>
        </article>

        <article className="mb-card">
          <h3 className="mb-card-title">Identity reference set</h3>
          <div className="mb-refs">
            {IDENTITY_REFS.map((r) => (
              <figure key={r.id} className="mb-ref">
                <img src={r.url} alt={r.label} loading="lazy" />
                <figcaption>{r.label}</figcaption>
              </figure>
            ))}
          </div>
          <p className="mb-lock mb-lock-note">
            These frames are attached to every image and video render so the face, locs, red shades
            and chains stay identical across all shots.
          </p>
        </article>

        <article className="mb-card">
          <h3 className="mb-card-title">Style lock</h3>
          <p className="mb-lock">{STYLE_LOCK}</p>
          <p className="mb-lock mb-lock-note">{NEGATIVE_LOCK}</p>
        </article>


        <article className="mb-card">
          <h3 className="mb-card-title">Palette</h3>
          <div className="mb-swatches">
            {PALETTE.map((c) => (
              <div key={c.hex} className="mb-swatch">
                <span style={{ background: c.hex }} />
                <b>{c.name}</b>
                <i>{c.hex}</i>
              </div>
            ))}
          </div>
        </article>

        <article className="mb-card">
          <h3 className="mb-card-title">Wardrobe library</h3>
          <div className="mb-chips">
            {wardrobe.map((w) => (
              <span key={w} className="sb-pill">
                {w}
              </span>
            ))}
          </div>
        </article>
      </div>

      <h3 className="mb-card-title mb-refs-title">Reference frames</h3>
      <div className="mb-refs">
        {refs.map((s) => (
          <figure key={s.id} className="mb-ref">
            <img src={s.image} alt={s.alt} loading="lazy" />
            <figcaption>
              {s.id} · {s.mood}
            </figcaption>
          </figure>
        ))}
      </div>
    </section>
  );
}
