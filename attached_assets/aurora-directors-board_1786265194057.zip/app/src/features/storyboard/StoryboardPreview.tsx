import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { buildPlan, useTimeline } from "./timelineStore";

const W = 1280;
const H = 720;

const fmt = (s: number) => {
  if (!Number.isFinite(s) || s < 0) s = 0;
  return `${Math.floor(s / 60)}:${Math.floor(s % 60)
    .toString()
    .padStart(2, "0")}`;
};

export function StoryboardPreview() {
  const { shots, order, timestamps, imageFor, audioSrc, audioName, setAudio } = useTimeline();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  const rafRef = useRef<number>(0);
  const startedAt = useRef<number>(0);
  const offsetRef = useRef<number>(0);

  const [duration, setDuration] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [recording, setRecording] = useState(false);
  const [note, setNote] = useState<string | null>(null);

  const plan = useMemo(
    () => buildPlan(shots, order, timestamps, imageFor, duration),
    [shots, order, timestamps, imageFor, duration],
  );

  const usingStamps = useMemo(
    () => Object.keys(timestamps).length >= 2 && duration > 0,
    [timestamps, duration],
  );

  // preload images
  const imagesRef = useRef<Map<string, HTMLImageElement>>(new Map());
  useEffect(() => {
    plan.items.forEach((it) => {
      if (imagesRef.current.has(it.image)) return;
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.src = it.image;
      imagesRef.current.set(it.image, img);
    });
  }, [plan]);

  const drawFrame = useCallback(
    (t: number) => {
      const canvas = canvasRef.current;
      const ctx = canvas?.getContext("2d");
      if (!canvas || !ctx) return;

      ctx.fillStyle = "#08070b";
      ctx.fillRect(0, 0, W, H);

      const idx = plan.items.findIndex((it) => t >= it.start && t < it.end);
      const item = plan.items[idx === -1 ? (t >= plan.total ? plan.items.length - 1 : 0) : idx];
      if (!item) return;

      const local = Math.max(0, t - item.start);
      const span = Math.max(0.35, item.end - item.start);
      const p = Math.min(1, local / span);

      const drawImg = (src: string, zoomFrom: number, alpha: number) => {
        const img = imagesRef.current.get(src);
        if (!img || !img.complete || !img.naturalWidth) return;
        const scale = Math.max(W / img.naturalWidth, H / img.naturalHeight) * zoomFrom;
        const dw = img.naturalWidth * scale;
        const dh = img.naturalHeight * scale;
        ctx.save();
        ctx.globalAlpha = alpha;
        ctx.drawImage(img, (W - dw) / 2, (H - dh) / 2, dw, dh);
        ctx.restore();
      };

      // Ken Burns push-in on the active shot
      drawImg(item.image, 1.04 + p * 0.09, 1);

      // crossfade with the next shot in the last 0.5s
      const fade = 0.5;
      if (span - local < fade && plan.items[idx + 1]) {
        const a = (fade - (span - local)) / fade;
        drawImg(plan.items[idx + 1].image, 1.04, Math.max(0, Math.min(1, a)));
      }

      // cinematic bars + lower third
      ctx.fillStyle = "rgba(4,4,8,0.92)";
      ctx.fillRect(0, 0, W, 44);
      ctx.fillRect(0, H - 44, W, 44);

      const grad = ctx.createLinearGradient(0, H - 260, 0, H);
      grad.addColorStop(0, "rgba(0,0,0,0)");
      grad.addColorStop(1, "rgba(0,0,0,0.75)");
      ctx.fillStyle = grad;
      ctx.fillRect(0, H - 260, W, 260);

      ctx.fillStyle = "#ff2f56";
      ctx.font = "600 20px system-ui, sans-serif";
      ctx.fillText(`SHOT ${item.shot.id}`, 56, H - 132);

      ctx.fillStyle = "#f6f4f8";
      ctx.font = "700 42px system-ui, sans-serif";
      ctx.fillText(item.shot.title, 56, H - 92);

      ctx.fillStyle = "rgba(246,244,248,0.66)";
      ctx.font = "400 20px system-ui, sans-serif";
      ctx.fillText(`${item.shot.frame} · ${item.shot.mood}`, 56, H - 62);

      ctx.fillStyle = "rgba(246,244,248,0.75)";
      ctx.font = "500 18px system-ui, sans-serif";
      ctx.fillText(fmt(t), W - 110, H - 62);

      // progress bar
      ctx.fillStyle = "rgba(255,255,255,0.14)";
      ctx.fillRect(56, H - 34, W - 112, 4);
      ctx.fillStyle = "#ff2f56";
      ctx.fillRect(56, H - 34, (W - 112) * Math.min(1, t / (plan.total || 1)), 4);
    },
    [plan],
  );

  // render loop
  useEffect(() => {
    const tick = () => {
      const a = audioRef.current;
      const t = audioSrc && a ? a.currentTime : offsetRef.current + (performance.now() - startedAt.current) / 1000;
      if (t >= plan.total) {
        drawFrame(plan.total);
        setTime(plan.total);
        setPlaying(false);
        offsetRef.current = 0;
        if (a) a.pause();
        return;
      }
      setTime(t);
      drawFrame(t);
      rafRef.current = requestAnimationFrame(tick);
    };
    if (playing) rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, [playing, plan, drawFrame, audioSrc]);

  // first paint
  useEffect(() => {
    drawFrame(time);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [drawFrame]);

  const play = () => {
    if (!plan.items.length) return;
    const a = audioRef.current;
    if (audioSrc && a) {
      if (a.currentTime >= plan.total) a.currentTime = 0;
      a.play().catch(() => {});
    } else {
      if (time >= plan.total) offsetRef.current = 0;
      else offsetRef.current = time;
      startedAt.current = performance.now();
    }
    setPlaying(true);
  };

  const pause = () => {
    audioRef.current?.pause();
    offsetRef.current = time;
    setPlaying(false);
  };

  const seek = (t: number) => {
    offsetRef.current = t;
    startedAt.current = performance.now();
    if (audioRef.current) audioRef.current.currentTime = t;
    setTime(t);
    drawFrame(t);
  };

  const render = async () => {
    const canvas = canvasRef.current;
    if (!canvas || recording || !plan.items.length) return;
    setNote(null);
    try {
      const stream = canvas.captureStream(30);
      const a = audioRef.current as (HTMLAudioElement & { captureStream?: () => MediaStream }) | null;
      if (audioSrc && a?.captureStream) {
        try {
          a.captureStream()
            .getAudioTracks()
            .forEach((tr) => stream.addTrack(tr));
        } catch {
          /* audio capture unsupported — render silent */
        }
      }
      const rec = new MediaRecorder(stream, { mimeType: "video/webm" });
      const chunks: Blob[] = [];
      rec.ondataavailable = (e) => e.data.size && chunks.push(e.data);
      rec.onstop = () => {
        const blob = new Blob(chunks, { type: "video/webm" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = "storyboard-preview.webm";
        link.click();
        setTimeout(() => URL.revokeObjectURL(url), 4000);
        setRecording(false);
        setNote("Render complete — check your downloads.");
      };
      seek(0);
      rec.start();
      setRecording(true);
      play();
      const stop = () => rec.state !== "inactive" && rec.stop();
      window.setTimeout(stop, (plan.total + 0.6) * 1000);
    } catch (err) {
      setRecording(false);
      setNote(err instanceof Error ? err.message : "Rendering not supported in this browser.");
    }
  };

  return (
    <section className="pv-wrap" aria-label="Storyboard preview video">
      <div className="pv-head">
        <div>
          <h2 className="pv-title">Rendered preview</h2>
          <p className="pv-sub">
            {usingStamps
              ? `Cutting on your stamped timestamps across ${plan.items.length} shots.`
              : `No stamps yet — playing ${plan.items.length} shots at 3s each. Stamp shots in the Sequencer to sync to your track.`}
          </p>
        </div>
        <label className="pv-btn pv-btn-ghost">
          {audioSrc ? "Change track" : "Load audio"}
          <input
            type="file"
            accept="audio/*"
            hidden
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) setAudio(f);
            }}
          />
        </label>
      </div>

      <div className="pv-stage">
        <canvas ref={canvasRef} width={W} height={H} className="pv-canvas" />
        {recording && <span className="pv-rec">● RENDERING</span>}
      </div>

      {audioSrc && (
        <audio
          ref={audioRef}
          src={audioSrc}
          onLoadedMetadata={(e) => setDuration(e.currentTarget.duration || 0)}
          onEnded={() => setPlaying(false)}
          hidden
        />
      )}

      <div className="pv-controls">
        <button type="button" className="pv-btn pv-btn-primary" onClick={playing ? pause : play}>
          {playing ? "❚❚ Pause" : "▶ Play"}
        </button>
        <input
          className="pv-scrub"
          type="range"
          min={0}
          max={Math.max(0.1, plan.total)}
          step={0.05}
          value={Math.min(time, plan.total)}
          onChange={(e) => seek(Number(e.target.value))}
          aria-label="Scrub preview"
        />
        <span className="pv-time">
          {fmt(time)} / {fmt(plan.total)}
        </span>
        <button type="button" className="pv-btn" onClick={render} disabled={recording}>
          {recording ? "Rendering…" : "⬇ Render .webm"}
        </button>
      </div>

      <p className="pv-note">
        {note ?? (audioName ? `Track: ${audioName}` : "Renders in real time with audio when a track is loaded.")}
      </p>

      <div className="pv-strip">
        {plan.items.map((it) => (
          <button
            key={it.shot.id + it.start}
            type="button"
            className={`pv-chip ${time >= it.start && time < it.end ? "pv-chip-on" : ""}`}
            onClick={() => seek(it.start)}
          >
            <img src={it.image} alt="" />
            <span>
              {it.shot.id} · {fmt(it.start)}
            </span>
          </button>
        ))}
      </div>
    </section>
  );
}
