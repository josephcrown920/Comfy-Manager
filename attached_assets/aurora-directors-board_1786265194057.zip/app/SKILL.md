# SKILL.md — Director's Board studio agent

Teach the agent how to operate this storyboard studio.

## Core rules

1. The avatar is **identity-locked**. Never alter face, hair, eyewear or jewellery — only scene,
   wardrobe, camera and light. Always include `CHARACTER_LOCK` + `STYLE_LOCK` and send the identity
   reference frames from `identityRefs.ts` with every render.
2. Prompts stay under 900 characters, photoreal, 16:9, no text/logos/watermarks.
3. One board = one seed. Reuse `seedLine()` so grade, grain and lens character stay consistent.

## Model routing (src/features/storyboard/models.ts)

| Role | Models | Endpoint |
| --- | --- | --- |
| Brain | `openai/gpt-5.6-sol`, `openai/gpt-5.6-terra` | `/v1/responses` (json_schema, strict) |
| Brain | `google/gemini-3.6-flash`, `google/gemini-3.1-pro-preview` | `/v1/chat/completions` (json_schema) |
| Frames | `google/gemini-3-pro-image` (messages + modalities), `openai/gpt-image-2` (prompt) | `/v1/images/generations`, streamed |
| Motion | `google/veo-3.1-lite` | `/v1/videos` |

Claude (`anthropic/*`), Grok (`xai/*`) and Seedance 2.5 (`bytedance/seedance-2.5`) are registered but
disabled — the Lovable gateway does not proxy them. To enable: add the provider key as a secret and
branch on the vendor inside `src/routes/api/brain.ts` (or the render route for Seedance) before the
gateway call. Never silently fall back to a different vendor.

Never carry one model's request body to another: Gemini image models take `messages` + `modalities`,
OpenAI image models take `prompt`. Never set `reasoning` on a chat-completions call.

## Skills the agent should perform

- **write-shot-prompts** — `writeShotPrompts()`: one render-ready prompt, negative line and
  continuity note per deck shot.
- **fill-flow** — `fillFlowNodes()`: populate every node of a flow from deck order + audio
  timecodes; iterator nodes get one row per variation.
- **expand-moodboard** — `expandMoodboard()`: invent new non-duplicate setups with label, scene,
  camera, wardrobe, continuity and prompt.
- **render-frame** — `streamImage("/api/generate-shot", prompt, onFrame, references, vidModel)`;
  blur partial frames, clear blur on the final event.
- **render-character-sheet** — eight angles (front, 3/4, profile, back, low, high, close, full body)
  on a neutral charcoal sweep, identical wardrobe in every panel.
- **canvas-compose** — character-sheet node feeds prompt nodes, prompt nodes feed frame/video nodes;
  links are curved dashed paths.
- **admin-swap-photo** — write `settings.imageOverrides[shotId]` via `setImageOverride`; a `null`
  clears it. Never mutate the shipped asset files.

## Failure handling

429 = rate limited (back off), 402 = credits exhausted (tell the user to top up), 400 = the body
doesn't match the selected model (fix from the error, don't retry unchanged).

## Aurora Studio surface (`/studio`)

Second workspace, merged in from the Aurora upgrade. Board state lives in `src/lib/board-store.ts`
(localStorage, seeded from `shots.ts` — the same deck the Director's Board uses). Nodes are chained
by edges; `chainOrder()` is the single source of truth for playback and export order.

- **direct-the-shoot** — `/api/chat` streams the Director agent (`google/gemini-3.6-flash`) with the
  `propose_shot` tool. Never accept a proposal into the board without the user's click.
- **queue-video-render** — `queueRenderJob()` inserts into `render_jobs` with `status: "queued"`.
  A GPU worker (`cli/aurora-worker.mjs`) claims it via `/api/public/gpu/claim` and reports back via
  `/api/public/gpu/complete`. Seedance 2.5 / LTX / LTX-2 run on the worker, not the gateway.
- **export-board-zip** — `exportBoardZip()` bundles frames + a manifest client-side with `fflate`.

Rules: the GPU routes live under `/api/public/*` and must keep validating bodies with Zod and using
`supabaseAdmin` only inside the handler. Never point the studio's video models at the Lovable
gateway — they are worker-only.
