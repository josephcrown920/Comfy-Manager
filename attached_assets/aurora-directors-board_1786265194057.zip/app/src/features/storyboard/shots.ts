import shot01 from "@/assets/storyboard/shot-01-miami-convertible.jpg.asset.json";
import shot02 from "@/assets/storyboard/shot-02-blue-neon-studio.jpg.asset.json";
import shot03 from "@/assets/storyboard/shot-03-red-blue-portrait.jpg.asset.json";
import shot04 from "@/assets/storyboard/shot-04-red-puffer-rooftop.jpg.asset.json";
import shot05 from "@/assets/storyboard/shot-05-yellow-puffer-street.jpg.asset.json";
import shot06 from "@/assets/storyboard/shot-06-blue-puffer-subway.jpg.asset.json";
import shot07 from "@/assets/storyboard/shot-07-court-sneakers.jpg.asset.json";
import shot08 from "@/assets/storyboard/shot-08-pink-mic-performance.jpg.asset.json";
import shot09 from "@/assets/storyboard/shot-09-alley-leather.jpg.asset.json";
import shot10 from "@/assets/storyboard/shot-10-concert-walkout.jpg.asset.json";
import shot01Alt from "@/assets/storyboard/shot-01-alt.jpg.asset.json";
import shot02Alt from "@/assets/storyboard/shot-02-alt.jpg.asset.json";
import shot03Alt from "@/assets/storyboard/shot-03-alt.jpg.asset.json";
import shot04Alt from "@/assets/storyboard/shot-04-alt.jpg.asset.json";
import shot05Alt from "@/assets/storyboard/shot-05-alt.jpg.asset.json";
import shot06Alt from "@/assets/storyboard/shot-06-alt.jpg.asset.json";
import shot07Alt from "@/assets/storyboard/shot-07-alt.jpg.asset.json";
import shot08Alt from "@/assets/storyboard/shot-08-alt.jpg.asset.json";
import shot09Alt from "@/assets/storyboard/shot-09-alt.jpg.asset.json";
import shot10Alt from "@/assets/storyboard/shot-10-alt.jpg.asset.json";

export type ShotVariant = {
  image: string;
  frame: string;
  wardrobe: string;
  label: string;
};

export type Shot = {
  id: string;
  title: string;
  type: string;
  image: string;
  alt: string;
  frame: string;
  wardrobe: string;
  mood: string;
  note: string;
  variants: ShotVariant[];
};

const v = (image: string, label: string, frame: string, wardrobe: string): ShotVariant => ({
  image,
  label,
  frame,
  wardrobe,
});

export const shots: Shot[] = [
  {
    id: "01",
    title: "Ocean Drive Pull-Up",
    type: "hero opener",
    image: shot01.url,
    alt: "Artist leaning out of a red convertible on a neon-lit Miami street in the rain.",
    frame: "Low rolling side shot",
    wardrobe: "Pink hoodie, black utility vest, red shades",
    mood: "Neon, humid, high-status",
    note: "Use this as the establishing flex shot before the verse lands.",
    variants: [
      v(shot01.url, "Original", "Low rolling side shot", "Pink hoodie, black utility vest, red shades"),
      v(shot01Alt.url, "Front hood angle", "Front-on hood ornament perspective", "Black leather bomber w/ red racing stripes, gold chain"),
    ],
  },
  {
    id: "02",
    title: "Blue Voltage",
    type: "editorial profile",
    image: shot02.url,
    alt: "Artist in a blue neon studio wearing a black leather jacket and layered diamond chains.",
    frame: "Locked-off profile medium",
    wardrobe: "Black leather jacket, white tee, heavy chains",
    mood: "Electric, fashion-forward, cold glow",
    note: "Perfect for transition bars or a slow intro with animated light flicker.",
    variants: [
      v(shot02.url, "Original", "Locked-off profile medium", "Black leather jacket, white tee, heavy chains"),
      v(shot02Alt.url, "Low 3/4 hero", "Low three-quarter angle looking up", "Silver metallic puffer vest, mesh top, silver rings"),
    ],
  },
  {
    id: "03",
    title: "Red Lens Close-Up",
    type: "beauty detail",
    image: shot03.url,
    alt: "Tight portrait of the artist wearing sculpted red sunglasses under moody blue and red lighting.",
    frame: "Extreme close-up",
    wardrobe: "Signature shades, pendant, dark performance tee",
    mood: "Intense, iconic, intimate",
    note: "Cut this on punchlines for a signature face card moment.",
    variants: [
      v(shot03.url, "Original", "Extreme close-up", "Signature shades, pendant, dark performance tee"),
      v(shot03Alt.url, "Side macro", "Macro side profile on ear + jawline", "Satin black shirt, silver cross pendant"),
    ],
  },
  {
    id: "04",
    title: "Rooftop Sunrise",
    type: "anthem frame",
    image: shot04.url,
    alt: "Artist in a glossy red puffer jacket standing on a wet rooftop with the skyline behind him at sunrise.",
    frame: "Wide hero silhouette",
    wardrobe: "Red puffer, black tee, hood up",
    mood: "Triumphant, reflective, cinematic",
    note: "Great for the hook or first chorus with lens flares and skyline movement.",
    variants: [
      v(shot04.url, "Original", "Wide hero silhouette", "Red puffer, black tee, hood up"),
      v(shot04Alt.url, "Behind into sun", "Low angle from behind toward sunrise", "Cream shearling over burgundy hoodie, cargo pants"),
    ],
  },
  {
    id: "05",
    title: "Taxi Crosswalk",
    type: "fashion walk",
    image: shot05.url,
    alt: "Artist crossing a city street in a yellow puffer jacket with taxis blurring around him.",
    frame: "Center walk-in wide",
    wardrobe: "Yellow puffer, black tee, red shades",
    mood: "Fast, urban, designer energy",
    note: "Use subtle speed ramps so the traffic moves faster than the subject.",
    variants: [
      v(shot05.url, "Original", "Center walk-in wide", "Yellow puffer, black tee, red shades"),
      v(shot05Alt.url, "Top-down overhead", "Overhead top-down look", "Orange varsity jacket, cargo shorts, chunky white sneakers"),
    ],
  },
  {
    id: "06",
    title: "Subway Silence",
    type: "back view mood",
    image: shot06.url,
    alt: "Artist seen from behind in a glossy blue puffer jacket on an empty foggy subway platform.",
    frame: "Symmetrical back shot",
    wardrobe: "Blue puffer, hood up",
    mood: "Alone, icy, suspenseful",
    note: "Ideal for the bridge or a beat switch before the next sequence hits.",
    variants: [
      v(shot06.url, "Original", "Symmetrical back shot", "Blue puffer, hood up"),
      v(shot06Alt.url, "Side dolly", "Camera dolly side profile walking", "Charcoal wool trench, black turtleneck, silver chain"),
    ],
  },
  {
    id: "07",
    title: "Courtside Dusk",
    type: "product hero",
    image: shot07.url,
    alt: "Artist seated on a basketball court at dusk with light blue sneakers large in the foreground.",
    frame: "Low sneaker-led angle",
    wardrobe: "Black hoodie, statement sneakers, chain",
    mood: "Sport-luxury, grounded, aspirational",
    note: "This frame sells the sneaker story without losing the artist identity.",
    variants: [
      v(shot07.url, "Original", "Low sneaker-led angle", "Black hoodie, statement sneakers, chain"),
      v(shot07Alt.url, "Full court wide", "High wide showing full court", "White basketball jersey, red mesh shorts, red high-tops"),
    ],
  },
  {
    id: "08",
    title: "Pink Mic Attack",
    type: "performance close-up",
    image: shot08.url,
    alt: "Artist singing into a vintage microphone against a hot pink backdrop.",
    frame: "Aggressive tight performance",
    wardrobe: "Black graphic tee, rings, signature shades",
    mood: "Loud, playful, front-facing",
    note: "Strong option for ad-libs, hooks, or lyric typography overlays.",
    variants: [
      v(shot08.url, "Original", "Aggressive tight performance", "Black graphic tee, rings, signature shades"),
      v(shot08Alt.url, "Full-body wide", "Full-body wide low angle", "Hot pink satin tracksuit, gold chain, white sneakers"),
    ],
  },
  {
    id: "09",
    title: "Back Alley Smoke",
    type: "street noir",
    image: shot09.url,
    alt: "Artist standing in a graffiti-lined alley wearing a leather jacket and boots with steam rising nearby.",
    frame: "High angle wide",
    wardrobe: "Leather jacket, brown denim, wheat boots",
    mood: "Gritty, nocturnal, cinematic",
    note: "This plays like a story beat between glamour scenes.",
    variants: [
      v(shot09.url, "Original", "High angle wide", "Leather jacket, brown denim, wheat boots"),
      v(shot09Alt.url, "Low dutch", "Low dutch angle", "Black hooded parka, distressed jeans, combat boots"),
    ],
  },
  {
    id: "10",
    title: "Walkout to Chaos",
    type: "finale moment",
    image: shot10.url,
    alt: "Artist walking toward camera through a crowd with phone lights and purple lasers in the background.",
    frame: "Runway-style crowd push",
    wardrobe: "Purple track jacket, washed jeans, red-purple kicks",
    mood: "Victory lap, concert heat, star power",
    note: "Use this as the closing ascent shot or the last chorus payoff.",
    variants: [
      v(shot10.url, "Original", "Runway-style crowd push", "Purple track jacket, washed jeans, red-purple kicks"),
      v(shot10Alt.url, "Over-shoulder into crowd", "Behind the artist, looking into crowd", "Shimmering silver bomber, black leather pants, white sneakers"),
    ],
  },
];
