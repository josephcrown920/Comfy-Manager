import { useRef, useState } from "react";
import { shots, type Shot } from "./shots";
import { useStudio } from "./studioStore";
import { BRAIN_MODELS, VID_MODELS } from "./models";

/**
 * Admin settings — swap the photos used on the front page (Shot Deck),
 * and choose which brain / vid-agent models the studio runs on.
 * Everything persists locally per browser via the studio store.
 */
export function AdminPanel({ deck = shots }: { deck?: Shot[] }) {
  const { settings, setBrainModel, setVidModel, setImageOverride, resetImageOverrides } =
    useStudio();
  const [urlDraft, setUrlDraft] = useState<Record<string, string>>({});
  const fileInputs = useRef<Record<string, HTMLInputElement | null>>({});

  const upload = (shotId: string, file: File) => {
    const reader = new FileReader();
    reader.onload = () => setImageOverride(shotId, String(reader.result));
    reader.readAsDataURL(file);
  };

  return (
    <div className="adm-wrap">
      <section className="adm-block">
        <header className="adm-head">
          <h3 className="adm-title">Agent models</h3>
          <p className="adm-sub">
            The brain writes prompts, flows and shot bibles. The vid agent renders frames and motion.
          </p>
        </header>

        <div className="adm-model-grid">
          <fieldset className="adm-fieldset">
            <legend>Brain (reasoning)</legend>
            {BRAIN_MODELS.map((m) => (
              <label
                key={m.id}
                className={`adm-model ${settings.brainModel === m.id ? "adm-model-on" : ""} ${
                  m.available ? "" : "adm-model-off"
                }`}
              >
                <input
                  type="radio"
                  name="brain-model"
                  value={m.id}
                  disabled={!m.available}
                  checked={settings.brainModel === m.id}
                  onChange={() => setBrainModel(m.id)}
                />
                <span className="adm-model-body">
                  <span className="adm-model-label">
                    {m.label}
                    <span className="adm-vendor">{m.vendor}</span>
                  </span>
                  <span className="adm-model-hint">{m.hint}</span>
                </span>
              </label>
            ))}
          </fieldset>

          <fieldset className="adm-fieldset">
            <legend>Vid agent (frames &amp; motion)</legend>
            {VID_MODELS.map((m) => (
              <label
                key={m.id}
                className={`adm-model ${settings.vidModel === m.id ? "adm-model-on" : ""} ${
                  m.available ? "" : "adm-model-off"
                }`}
              >
                <input
                  type="radio"
                  name="vid-model"
                  value={m.id}
                  disabled={!m.available}
                  checked={settings.vidModel === m.id}
                  onChange={() => setVidModel(m.id)}
                />
                <span className="adm-model-body">
                  <span className="adm-model-label">
                    {m.label}
                    <span className="adm-vendor">{m.kind}</span>
                  </span>
                  <span className="adm-model-hint">{m.hint}</span>
                </span>
              </label>
            ))}
          </fieldset>
        </div>
      </section>

      <section className="adm-block">
        <header className="adm-head">
          <h3 className="adm-title">Front page photos</h3>
          <p className="adm-sub">
            Replace any deck frame with your own image — upload a file or paste a URL. Overrides show
            up everywhere the shot is used (deck, canvas, character sheet, sequencer).
          </p>
          <button type="button" className="dir-mini-btn" onClick={resetImageOverrides}>
            Reset all photos
          </button>
        </header>

        <div className="adm-photo-grid">
          {deck.map((shot) => {
            const override = settings.imageOverrides[shot.id];
            return (
              <article key={shot.id} className="adm-photo">
                <img className="adm-photo-img" src={override ?? shot.image} alt={shot.alt} />
                <div className="adm-photo-body">
                  <span className="adm-photo-id">
                    {shot.id} · {shot.title}
                    {override && <em className="adm-flag">custom</em>}
                  </span>
                  <div className="adm-photo-actions">
                    <button
                      type="button"
                      className="dir-mini-btn"
                      onClick={() => fileInputs.current[shot.id]?.click()}
                    >
                      Upload
                    </button>
                    <input
                      ref={(el) => {
                        fileInputs.current[shot.id] = el;
                      }}
                      className="adm-file"
                      type="file"
                      accept="image/*"
                      aria-label={`Upload replacement photo for shot ${shot.id}`}
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) upload(shot.id, file);
                        e.target.value = "";
                      }}
                    />
                    <button
                      type="button"
                      className="dir-mini-btn"
                      disabled={!override}
                      onClick={() => setImageOverride(shot.id, null)}
                    >
                      Revert
                    </button>
                  </div>
                  <div className="adm-url-row">
                    <input
                      className="dir-input"
                      placeholder="https://…"
                      value={urlDraft[shot.id] ?? ""}
                      onChange={(e) =>
                        setUrlDraft((prev) => ({ ...prev, [shot.id]: e.target.value }))
                      }
                    />
                    <button
                      type="button"
                      className="dir-mini-btn"
                      onClick={() => {
                        const url = (urlDraft[shot.id] ?? "").trim();
                        if (url) setImageOverride(shot.id, url);
                        setUrlDraft((prev) => ({ ...prev, [shot.id]: "" }));
                      }}
                    >
                      Use URL
                    </button>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      </section>
    </div>
  );
}
