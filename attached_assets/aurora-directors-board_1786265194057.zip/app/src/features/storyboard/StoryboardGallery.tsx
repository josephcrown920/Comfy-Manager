import { useEffect, useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { shots, type Shot } from "./shots";
import { StoryboardSequencer } from "./StoryboardSequencer";
import { ShotGenerator } from "./ShotGenerator";
import { StoryboardPreview } from "./StoryboardPreview";
import { FlowsBoard } from "./FlowsBoard";
import { Moodboard } from "./Moodboard";
import { BrainBoard } from "./BrainBoard";
import { CanvasBoard } from "./CanvasBoard";
import { CharacterSheet } from "./CharacterSheet";
import { AdminPanel } from "./AdminPanel";
import { configureBrain } from "./brain";
import { TimelineProvider } from "./timelineStore";
import { StudioProvider, useStudio } from "./studioStore";

type Props = {
  title?: string;
  subtitle?: string;
  data?: Shot[];
  showHero?: boolean;
};

type Tab =
  | "deck"
  | "canvas"
  | "character"
  | "moodboard"
  | "brain"
  | "flows"
  | "generate"
  | "sequence"
  | "preview"
  | "admin";

const TABS: { id: Tab; label: string }[] = [
  { id: "deck", label: "Shot Deck" },
  { id: "canvas", label: "Canvas" },
  { id: "character", label: "Character Sheet" },
  { id: "moodboard", label: "Moodboard" },
  { id: "brain", label: "Brain" },
  { id: "flows", label: "Flows" },
  { id: "generate", label: "AI Generate" },
  { id: "sequence", label: "Sequencer" },
  { id: "preview", label: "Preview Video" },
  { id: "admin", label: "Admin" },
];


export function StoryboardGallery(props: Props) {
  return (
    <StudioProvider>
      <GalleryInner {...props} />
    </StudioProvider>
  );
}

function BoardBar() {
  const { boards, board, createBoard, switchBoard, renameBoard, deleteBoard } = useStudio();
  const [creating, setCreating] = useState(false);
  const [name, setName] = useState("");
  const [base, setBase] = useState<"deck" | "blank">("blank");

  return (
    <div className="dir-board-bar">
      <label className="dir-board-label" htmlFor="bd-select">
        Storyboard
      </label>
      <select
        id="bd-select"
        className="dir-board-select"
        value={board.id}
        onChange={(e) => switchBoard(e.target.value)}
      >
        {boards.map((b) => (
          <option key={b.id} value={b.id}>
            {b.name}
          </option>
        ))}
      </select>
      <button type="button" className="dir-mini-btn" onClick={() => setCreating((v) => !v)}>
        + New storyboard
      </button>
      <button
        type="button"
        className="dir-mini-btn"
        onClick={() => {
          const next = window.prompt("Rename storyboard", board.name);
          if (next) renameBoard(board.id, next);
        }}
      >
        Rename
      </button>
      <button
        type="button"
        className="dir-mini-btn"
        disabled={boards.length === 1}
        onClick={() => deleteBoard(board.id)}
      >
        Delete
      </button>

      {creating && (
        <div className="dir-board-new">
          <input
            className="dir-input"
            placeholder="Storyboard name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <div className="dir-preset-row">
            {(["blank", "deck"] as const).map((b) => (
              <button
                key={b}
                type="button"
                className={`dir-chip dir-chip-sm ${base === b ? "dir-chip-on" : ""}`}
                onClick={() => setBase(b)}
              >
                {b === "blank" ? "Blank board" : "Start from reference deck"}
              </button>
            ))}
          </div>
          <button
            type="button"
            className="dir-btn dir-btn-primary"
            onClick={() => {
              createBoard(name, base);
              setName("");
              setCreating(false);
            }}
          >
            Create
          </button>
        </div>
      )}
    </div>
  );
}

function GalleryInner({
  title = "Director's Board",
  subtitle = "A consistency-locked music video deck — same avatar, same palette, every frame.",
  data = shots,
  showHero = true,
}: Props) {
  const { board, settings } = useStudio();
  const [tab, setTab] = useState<Tab>("flows");
  const [generated, setGenerated] = useState<Shot[]>([]);
  const [active, setActive] = useState<Shot | null>(null);
  const [directorNote, setDirectorNote] = useState("");

  useEffect(() => configureBrain(settings.brainModel), [settings.brainModel]);

  const base = board.base === "blank" ? [] : data;
  const all = useMemo(
    () =>
      [...base, ...generated].map((s) =>
        settings.imageOverrides[s.id] ? { ...s, image: settings.imageOverrides[s.id] } : s,
      ),
    [base, generated, settings.imageOverrides],
  );


  return (
    <TimelineProvider key={board.id} shots={all}>
      <main className="sb-shell">
        {showHero && (
          <header className="sb-topbar">
            <div className="sb-topbar-inner">
              <div className="dir-board-header">
                <div>
                  <BoardBar />
                  <h1 className="sb-wordmark">{title}</h1>
                  <p className="sb-tagline">{subtitle}</p>
                </div>
                <div className="dir-rec">
                  <Link to="/studio" className="dir-mini-btn">
                    Open Aurora Studio →
                  </Link>
                  <span className="dir-rec-label">
                    REC // {board.name.replace(/\s+/g, "_").toUpperCase()}
                  </span>
                  <span className="dir-rec-dot" />
                </div>
              </div>

              <nav className="sb-tabs" aria-label="Storyboard views">
                {TABS.map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    className={`sb-tab ${tab === t.id ? "sb-tab-on" : ""}`}
                    onClick={() => setTab(t.id)}
                  >
                    {t.label}
                  </button>
                ))}
                <span className="sb-count">{all.length} frames</span>
              </nav>
            </div>
          </header>
        )}

        <div className="sb-workspace">
          {tab === "deck" && (
            <section className="sb-grid" aria-label="Storyboard frames">
              {all.length === 0 && (
                <p className="pv-sub">
                  Blank storyboard — generate frames in Brain, Flows or AI Generate to fill this deck.
                </p>
              )}
              {all.map((shot) => (
                <button
                  key={shot.id}
                  type="button"
                  className="sb-tile"
                  onClick={() => setActive(shot)}
                  aria-label={`Open shot ${shot.id}: ${shot.title}`}
                >
                  <img className="sb-tile-img" src={shot.image} alt={shot.alt} loading="lazy" />
                  <span className="sb-tile-num">{shot.id}</span>
                  <span className="sb-tile-overlay">
                    <span className="sb-tile-title">{shot.title}</span>
                    <span className="sb-tile-meta">
                      {shot.frame} · {shot.mood}
                    </span>
                  </span>
                </button>
              ))}
            </section>
          )}

          {tab === "moodboard" && (
            <div className="sb-pane">
              <Moodboard shots={all} onAdd={(s) => setGenerated((prev) => [...prev, s])} />
            </div>
          )}

          {tab === "brain" && (
            <div className="sb-pane">
              <BrainBoard onAdd={(s) => setGenerated((prev) => [...prev, s])} />
            </div>
          )}

          {tab === "flows" && (
            <div className="sb-pane">
              <FlowsBoard
                shots={all}
                onAdd={(s) => setGenerated((prev) => [...prev, s])}
                onOpenPreview={() => setTab("preview")}
                directorNote={directorNote}
              />
            </div>
          )}

          {tab === "generate" && (
            <div className="sb-pane">
              <ShotGenerator onAdd={(s) => setGenerated((prev) => [...prev, s])} />
            </div>
          )}

          {tab === "sequence" && (
            <div className="sb-pane">
              <StoryboardSequencer shots={all} />
            </div>
          )}

          {tab === "preview" && (
            <div className="sb-pane">
              <StoryboardPreview />
            </div>
          )}

          {tab === "canvas" && (
            <div className="sb-pane sb-pane-flush">
              <CanvasBoard shots={all} />
            </div>
          )}

          {tab === "character" && (
            <div className="sb-pane">
              <CharacterSheet />
            </div>
          )}

          {tab === "admin" && (
            <div className="sb-pane">
              <AdminPanel deck={data} />
            </div>
          )}

        </div>

        {/* Creative Assistant */}
        <div className="dir-assistant">
          <div className="dir-assistant-inner">
            <div className="dir-assistant-copy">
              <h4>Director's Creative Assistant</h4>
              <p>
                Aligning visual consistency across the board. Current prompt weights favoring locked identity.
              </p>
            </div>
            <div className="dir-assistant-input">
              <input
                type="text"
                placeholder="Add global direction (e.g., 'Make all shots colder')"
                value={directorNote}
                onChange={(e) => setDirectorNote(e.target.value)}
              />
              <button type="button" onClick={() => {}}>
                Apply to board
              </button>
            </div>
          </div>
        </div>

        {active && (
          <div
            className="sb-lightbox"
            role="dialog"
            aria-modal="true"
            aria-label={active.title}
            onClick={() => setActive(null)}
          >
            <div className="sb-lightbox-inner" onClick={(e) => e.stopPropagation()}>
              <img src={active.image} alt={active.alt} className="sb-lightbox-img" />
              <div className="sb-lightbox-body">
                <span className="sb-tile-meta">
                  Shot {active.id} · {active.type}
                </span>
                <h2 className="sb-lightbox-title">{active.title}</h2>
                <p className="sb-lightbox-copy">{active.note}</p>
                <div className="sb-lightbox-pills">
                  <span className="sb-pill">{active.frame}</span>
                  <span className="sb-pill">{active.wardrobe}</span>
                  <span className="sb-pill">{active.mood}</span>
                </div>
                <button type="button" className="sb-btn-sm" onClick={() => setActive(null)}>
                  Close
                </button>
              </div>
            </div>
          </div>
        )}
      </main>
    </TimelineProvider>
  );
}

export { shots };
export type { Shot };
