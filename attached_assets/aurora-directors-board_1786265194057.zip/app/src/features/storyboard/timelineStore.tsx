import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from "react";
import type { Shot } from "./shots";

export type SectionId = "intro" | "verse" | "chorus" | "bridge" | "outro";

export const SECTIONS: { id: SectionId; label: string; hint: string }[] = [
  { id: "intro", label: "Intro", hint: "Cold open / establishing" },
  { id: "verse", label: "Verse", hint: "Story + character build" },
  { id: "chorus", label: "Chorus", hint: "Anthem energy, big frames" },
  { id: "bridge", label: "Bridge", hint: "Beat switch or mood pivot" },
  { id: "outro", label: "Outro", hint: "Payoff / walk-off" },
];

type Ctx = {
  shots: Shot[];
  order: string[];
  setOrder: React.Dispatch<React.SetStateAction<string[]>>;
  assignment: Record<string, SectionId>;
  setAssignment: React.Dispatch<React.SetStateAction<Record<string, SectionId>>>;
  variantIdx: Record<string, number>;
  setVariantIdx: React.Dispatch<React.SetStateAction<Record<string, number>>>;
  timestamps: Record<string, number>;
  setTimestamps: React.Dispatch<React.SetStateAction<Record<string, number>>>;
  audioSrc: string | null;
  audioName: string;
  setAudio: (file: File) => void;
  reset: () => void;
  /** Ordered playback plan: shot + start/end seconds. */
  imageFor: (shot: Shot) => string;
};

const TimelineCtx = createContext<Ctx | null>(null);

function defaultAssignment(shots: Shot[]) {
  const map: Record<string, SectionId> = {};
  shots.forEach((s) => {
    const n = Number(s.id);
    if (n <= 2) map[s.id] = "intro";
    else if (n === 4 || n === 8) map[s.id] = "chorus";
    else if (n === 6 || n === 9) map[s.id] = "bridge";
    else if (n === 10) map[s.id] = "outro";
    else map[s.id] = "verse";
  });
  return map;
}

export function TimelineProvider({ shots, children }: { shots: Shot[]; children: ReactNode }) {
  const [order, setOrder] = useState<string[]>(() => shots.map((s) => s.id));
  const [assignment, setAssignment] = useState(() => defaultAssignment(shots));
  const [variantIdx, setVariantIdx] = useState<Record<string, number>>(() =>
    Object.fromEntries(shots.map((s) => [s.id, 0])),
  );
  const [timestamps, setTimestamps] = useState<Record<string, number>>({});
  const [audioSrc, setAudioSrc] = useState<string | null>(null);
  const [audioName, setAudioName] = useState("");

  // keep newly generated shots in the order list
  const syncedOrder = useMemo(() => {
    const known = new Set(order);
    const extras = shots.map((s) => s.id).filter((id) => !known.has(id));
    return extras.length ? [...order, ...extras] : order;
  }, [order, shots]);

  const setAudio = useCallback((file: File) => {
    const url = URL.createObjectURL(file);
    setAudioSrc((prev) => {
      if (prev) URL.revokeObjectURL(prev);
      return url;
    });
    setAudioName(file.name);
    setTimestamps({});
  }, []);

  const imageFor = useCallback(
    (shot: Shot) => {
      const idx = variantIdx[shot.id] ?? 0;
      return shot.variants?.[idx]?.image ?? shot.image;
    },
    [variantIdx],
  );

  const reset = useCallback(() => {
    setOrder(shots.map((s) => s.id));
    setAssignment(defaultAssignment(shots));
    setVariantIdx(Object.fromEntries(shots.map((s) => [s.id, 0])));
    setTimestamps({});
  }, [shots]);

  const value: Ctx = {
    shots,
    order: syncedOrder,
    setOrder,
    assignment,
    setAssignment,
    variantIdx,
    setVariantIdx,
    timestamps,
    setTimestamps,
    audioSrc,
    audioName,
    setAudio,
    reset,
    imageFor,
  };

  return <TimelineCtx.Provider value={value}>{children}</TimelineCtx.Provider>;
}

export function useTimeline() {
  const ctx = useContext(TimelineCtx);
  if (!ctx) throw new Error("useTimeline must be used inside TimelineProvider");
  return ctx;
}

export type PlanItem = { shot: Shot; start: number; end: number; image: string };

/** Build the playback plan from stamped timestamps, falling back to even spacing. */
export function buildPlan(
  shots: Shot[],
  order: string[],
  timestamps: Record<string, number>,
  imageFor: (s: Shot) => string,
  duration: number,
  perShotFallback = 3,
): { items: PlanItem[]; total: number } {
  const byId = new Map(shots.map((s) => [s.id, s]));
  const ordered = order.map((id) => byId.get(id)).filter(Boolean) as Shot[];
  if (!ordered.length) return { items: [], total: 0 };

  const stamped = ordered
    .filter((s) => Number.isFinite(timestamps[s.id]))
    .sort((a, b) => timestamps[a.id] - timestamps[b.id]);

  if (stamped.length >= 2 && duration > 0) {
    const items: PlanItem[] = stamped.map((shot, i) => ({
      shot,
      image: imageFor(shot),
      start: timestamps[shot.id],
      end: i + 1 < stamped.length ? timestamps[stamped[i + 1].id] : duration,
    }));
    return { items, total: duration };
  }

  const items: PlanItem[] = ordered.map((shot, i) => ({
    shot,
    image: imageFor(shot),
    start: i * perShotFallback,
    end: (i + 1) * perShotFallback,
  }));
  return { items, total: ordered.length * perShotFallback };
}
