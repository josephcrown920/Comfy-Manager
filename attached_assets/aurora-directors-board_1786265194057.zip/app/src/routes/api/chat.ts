import { createLovableAiGatewayProvider } from "@/lib/ai-gateway.server";
import { createFileRoute } from "@tanstack/react-router";
import { convertToModelMessages, streamText, tool, stepCountIs, type UIMessage } from "ai";
import { z } from "zod";

type Body = { messages?: unknown; boardContext?: string };

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { messages, boardContext } = (await request.json()) as Body;
        if (!Array.isArray(messages)) return new Response("Messages required", { status: 400 });
        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response("Missing LOVABLE_API_KEY", { status: 500 });

        const gateway = createLovableAiGatewayProvider(key);
        const model = gateway("google/gemini-3.6-flash");

        const result = streamText({
          model,
          system: `You are the Director, an AI collaborator helping the user build a music video storyboard.
You suggest shot ideas, wardrobe, camera language, and scene ordering.
When the user asks you to add or edit a shot, describe it clearly and use the propose_shot tool with concrete fields.
Keep replies concise and cinematic.

Current board context:
${boardContext ?? "(no shots yet)"}`,
          messages: await convertToModelMessages(messages as UIMessage[]),
          stopWhen: stepCountIs(6),
          tools: {
            propose_shot: tool({
              description:
                "Propose a new shot the user can accept into their storyboard. Use when the user asks for ideas or additions.",
              inputSchema: z.object({
                title: z.string(),
                shot_type: z.string(),
                frame: z.string(),
                wardrobe: z.string(),
                mood: z.string(),
                note: z.string(),
                scene: z.string(),
                image_prompt: z.string().describe("Prompt to generate a still for this shot."),
              }),
              execute: async (input) => ({ ...input, accepted: false }),
            }),
          },
        });

        return result.toUIMessageStreamResponse({ originalMessages: messages as UIMessage[] });
      },
    },
  },
});