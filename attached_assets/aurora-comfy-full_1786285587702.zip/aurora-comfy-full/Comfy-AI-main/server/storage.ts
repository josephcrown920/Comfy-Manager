import { type User, type InsertUser, type GeneratedImage, type InsertGeneratedImage } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createGeneratedImage(image: InsertGeneratedImage): Promise<GeneratedImage>;
  getGeneratedImages(limit?: number): Promise<GeneratedImage[]>;
  getGeneratedImage(id: number): Promise<GeneratedImage | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private images: GeneratedImage[];
  private imageIdCounter: number;

  constructor() {
    this.users = new Map();
    this.images = [];
    this.imageIdCounter = 1;
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createGeneratedImage(image: InsertGeneratedImage): Promise<GeneratedImage> {
    const newImage: GeneratedImage = {
      id: this.imageIdCounter++,
      ...image,
      createdAt: new Date(),
    };
    this.images.unshift(newImage);
    return newImage;
  }

  async getGeneratedImages(limit: number = 10): Promise<GeneratedImage[]> {
    return this.images.slice(0, limit);
  }

  async getGeneratedImage(id: number): Promise<GeneratedImage | undefined> {
    return this.images.find((img) => img.id === id);
  }
}

export const storage = new MemStorage();
