import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { Shot } from "./shots";
import { useStudio } from "./studioStore";

/**
 * Infinite canvas — draggable node workspace linking character sheets,
 * frame nodes and prompt nodes with curved connectors.
 */

type NodeKind = "character" | "frame" | "prompt" | "video";

type CanvasNode = {
  id: string;
  kind: NodeKind;
  title: string;
  body?: string;
  image?: string;
  x: number;
  y: number;
};

type Edge = { from: string; to: string };

const KIND_LABEL: Record<NodeKind, string> = {
  character: "Character sheet",
  frame: "Frame",
  prompt: "Prompt",
  video: "Video",
};

function seedNodes(shots: Shot[], overrides: Record<string, string>): CanvasNode[] {
  const nodes: CanvasNode[] = [
    {
      id: "char",
      kind: "character",
      title: "Locked avatar — turnaround",
      body: "Identity reference sheet. Every downstream node inherits this face, hair and eyewear.",
      image: overrides[shots[0]?.id ?? ""] ?? shots[0]?.image,
      x: 80,
      y: 200,
    },
    {
      id: "prompt-root",
      kind: "prompt",
      title: "Global direction",
      body: "Neon-noir music video, anamorphic 35mm, red / royal blue / hot pink on near-black.",
      x: 520,
      y: 60,
    },
  ];
  shots.slice(0, 4).forEach((shot, i) => {
    nodes.push({
      id: `frame-${shot.id}`,
      kind: "frame",
      title: `${shot.id} · ${shot.title}`,
      body: `${shot.frame} · ${shot.mood}`,
      image: overrides[shot.id] ?? shot.image,
      x: 940,
      y: 20 + i * 250,
    });
  });
  return nodes;
}

export function CanvasBoard({ shots }: { shots: Shot[] }) {
  const { settings } = useStudio();
  const [nodes, setNodes] = useState<CanvasNode[]>(() => seedNodes(shots, settings.imageOverrides));
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [zoom, setZoom] = useState(0.85);
  const [selected, setSelected] = useState<string | null>(null);
  const drag = useRef<{ id: string | null; dx: number; dy: number; panning: boolean }>({
    id: null,
    dx: 0,
    dy: 0,
    panning: false,
  });

  const edges: Edge[] = useMemo(() => {
    const frames = nodes.filter((n) => n.kind === "frame" || n.kind === "video");
    return [
      { from: "char", to: "prompt-root" },
      ...frames.map((f) => ({ from: "prompt-root", to: f.id })),
      ...frames.map((f) => ({ from: "char", to: f.id })),
    ].filter((e) => nodes.some((n) => n.id === e.from) && nodes.some((n) => n.id === e.to));
  }, [nodes]);

  const onNodeDown = (e: React.PointerEvent, node: CanvasNode) => {
    e.stopPropagation();
    setSelected(node.id);
    drag.current = {
      id: node.id,
      dx: e.clientX / zoom - node.x,
      dy: e.clientY / zoom - node.y,
      panning: false,
    };
  };

  const onSurfaceDown = (e: React.PointerEvent) => {
    setSelected(null);
    drag.current = { id: null, dx: e.clientX - pan.x, dy: e.clientY - pan.y, panning: true };
  };

  const onMove = useCallback(
    (e: PointerEvent) => {
      const d = drag.current;
      if (d.panning) {
        setPan({ x: e.clientX - d.dx, y: e.clientY - d.dy });
        return;
      }
      if (!d.id) return;
      setNodes((prev) =>
        prev.map((n) =>
          n.id === d.id ? { ...n, x: e.clientX / zoom - d.dx, y: e.clientY / zoom - d.dy } : n,
        ),
      );
    },
    [zoom],
  );

  const onUp = useCallback(() => {
    drag.current = { id: null, dx: 0, dy: 0, panning: false };
  }, []);

  useEffect(() => {
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    return () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
    };
  }, [onMove, onUp]);

  const addNode = (kind: NodeKind) => {
    const id = `${kind}-${Math.random().toString(36).slice(2, 7)}`;
    setNodes((prev) => [
      ...prev,
      {
        id,
        kind,
        title: kind === "prompt" ? "New prompt" : `New ${KIND_LABEL[kind].toLowerCase()}`,
        body: kind === "prompt" ? "Describe the beat this node covers…" : "Awaiting render",
        x: 520 + Math.random() * 260,
        y: 420 + Math.random() * 200,
      },
    ]);
    setSelected(id);
  };

  const NODE_W = 300;
  const NODE_H = 190;

  return (
    <div className="cv-wrap">
      <div className="cv-toolbar">
        <span className="cv-kicker">Infinite canvas</span>
        <div className="cv-tools">
          <button type="button" className="dir-mini-btn" onClick={() => addNode("prompt")}>
            + Prompt node
          </button>
          <button type="button" className="dir-mini-btn" onClick={() => addNode("frame")}>
            + Frame node
          </button>
          <button type="button" className="dir-mini-btn" onClick={() => addNode("video")}>
            + Video node
          </button>
          <button
            type="button"
            className="dir-mini-btn"
            onClick={() => setZoom((z) => Math.max(0.4, +(z - 0.1).toFixed(2)))}
          >
            −
          </button>
          <span className="cv-zoom">{Math.round(zoom * 100)}%</span>
          <button
            type="button"
            className="dir-mini-btn"
            onClick={() => setZoom((z) => Math.min(1.4, +(z + 0.1).toFixed(2)))}
          >
            +
          </button>
          <button
            type="button"
            className="dir-mini-btn"
            onClick={() => {
              setPan({ x: 0, y: 0 });
              setZoom(0.85);
              setNodes(seedNodes(shots, settings.imageOverrides));
            }}
          >
            Reset
          </button>
        </div>
      </div>

      <div className="cv-surface" onPointerDown={onSurfaceDown}>
        <div
          className="cv-scene"
          style={{ transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})` }}
        >
          <svg className="cv-links" aria-hidden>
            {edges.map((edge) => {
              const a = nodes.find((n) => n.id === edge.from)!;
              const b = nodes.find((n) => n.id === edge.to)!;
              const x1 = a.x + NODE_W;
              const y1 = a.y + NODE_H / 2;
              const x2 = b.x;
              const y2 = b.y + NODE_H / 2;
              const mid = (x1 + x2) / 2;
              return (
                <path
                  key={`${edge.from}-${edge.to}`}
                  className="cv-link"
                  d={`M ${x1} ${y1} C ${mid} ${y1}, ${mid} ${y2}, ${x2} ${y2}`}
                />
              );
            })}
          </svg>

          {nodes.map((node) => (
            <article
              key={node.id}
              className={`cv-node cv-node-${node.kind} ${selected === node.id ? "cv-node-on" : ""}`}
              style={{ left: node.x, top: node.y, width: NODE_W }}
              onPointerDown={(e) => onNodeDown(e, node)}
            >
              <span className="cv-node-label">{node.title}</span>
              <div className="cv-node-card">
                {node.kind === "prompt" ? (
                  <p className="cv-prompt-text">{node.body}</p>
                ) : node.image ? (
                  <div className="cv-node-media">
                    <img src={node.image} alt={node.title} loading="lazy" draggable={false} />
                  </div>
                ) : (
                  <div className="cv-node-empty">{KIND_LABEL[node.kind]}</div>
                )}
                {node.kind !== "prompt" && node.body && (
                  <div className="cv-node-caption">
                    <b>{node.body}</b>
                  </div>
                )}
                <div className="cv-chips">
                  <span className="cv-chip">
                    {node.kind === "video" ? "Veo 3.1" : node.kind === "prompt" ? "GPT-5.6" : "GPT Image"}
                  </span>
                  <span className="cv-chip">16:9</span>
                  <span className="cv-chip">4K</span>
                </div>
              </div>
              <span className="cv-port cv-port-in" aria-hidden />
              <span className="cv-port cv-port-out" aria-hidden />
            </article>
          ))}

        </div>
      </div>
    </div>
  );
}
