import { useMemo, useState } from "react";
import { FLOWS, type Flow, type FlowNode } from "./flows";
import type { Shot } from "./shots";
import { streamImage } from "@/lib/streamImage";
import { withIdentityLock } from "./characterLock";
import { IDENTITY_REFS, loadIdentityReferences } from "./identityRefs";
import { fillFlowNodes } from "./brain";
import { PromptHistory } from "./PromptHistory";
import { useStudio } from "./studioStore";
import { buildPlan, useTimeline } from "./timelineStore";


type Props = {
  shots: Shot[];
  onAdd: (shot: Shot) => void;
  onOpenPreview: () => void;
  directorNote?: string;
};

export function FlowsBoard({ shots, onAdd, onOpenPreview, directorNote = "" }: Props) {
  const [openId, setOpenId] = useState<string>(FLOWS[0].id);
  const flow = FLOWS.find((f) => f.id === openId) ?? FLOWS[0];

  return (
    <section className="fl-wrap" aria-label="AI production flows">
      <div className="dir-board-head">
        <div>
          <h2 className="dir-board-title">Director's Board</h2>
          <p className="dir-board-subtitle">{flow.label} — {flow.blurb}</p>
        </div>
      </div>

      <div className="fl-tablist" role="tablist">
        {FLOWS.map((f) => (
          <button
            key={f.id}
            role="tab"
            aria-selected={f.id === openId}
            type="button"
            className={`fl-tab ${f.id === openId ? "fl-tab-on" : ""}`}
            onClick={() => setOpenId(f.id)}
          >
            <span>{f.label}</span>
            <span className="fl-tags">
              {f.tags.map((t) => (
                <em key={t}>{t}</em>
              ))}
            </span>
          </button>
        ))}
      </div>

      {directorNote && (
        <div className="dir-note">
          <span className="dir-note-label">Director's note</span>
          <p>{directorNote}</p>
        </div>
      )}

      <FlowCanvas key={flow.id} flow={flow} shots={shots} onAdd={onAdd} onOpenPreview={onOpenPreview} />
    </section>
  );
}

function FlowCanvas({
  flow,
  shots,
  onAdd,
  onOpenPreview,
}: {
  flow: Flow;
  shots: Shot[];
  onAdd: (shot: Shot) => void;
  onOpenPreview: () => void;
}) {
  const demoImages = useMemo(() => shots.map((s) => s.image), [shots]);

  const [nodes, setNodes] = useState<FlowNode[]>(() => flow.nodes.map((n) => ({ ...n })));
  const [slots, setSlots] = useState<Record<string, string>>(() =>
    Object.fromEntries(
      flow.nodes
        .filter((n) => n.demo != null)
        .map((n) => [n.id, demoImages[(n.demo as number) % demoImages.length]]),
    ),
  );
  const [preview, setPreview] = useState<string | null>(null);
  const [isFinal, setIsFinal] = useState(false);
  const [busy, setBusy] = useState(false);
  const [autoBusy, setAutoBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const { order, timestamps, imageFor, audioName, assignment } = useTimeline();
  const { seed, seedLine, pushVersion } = useStudio();

  const setText = (id: string, text: string) =>
    setNodes((prev) => prev.map((n) => (n.id === id ? { ...n, text } : n)));

  const setRow = (id: string, i: number, value: string) =>
    setNodes((prev) =>
      prev.map((n) =>
        n.id === id && n.rows ? { ...n, rows: n.rows.map((r, ri) => (ri === i ? value : r)) } : n,
      ),
    );

  const composedPrompt = () => {
    const texts = nodes.filter((n) => n.text).map((n) => n.text!.trim());
    const rows = nodes.flatMap((n) => n.rows ?? []);
    return [...texts, rows.length ? `VARIATIONS:\n- ${rows.join("\n- ")}` : ""].filter(Boolean).join("\n\n");
  };

  const autoPopulate = async () => {
    if (autoBusy) return;
    setAutoBusy(true);
    setError(null);
    try {
      const plan = buildPlan(shots, order, timestamps, imageFor, 0).items;
      const res = await fillFlowNodes({
        seed,
        audioName: audioName || "no audio loaded",
        flow: { id: flow.id, label: flow.label, blurb: flow.blurb, outcome: flow.outcome },
        nodes: nodes.map((n) => ({
          id: n.id,
          kind: n.kind,
          title: n.title,
          text: n.text,
          rows: n.rows,
        })),
        deck: shots.map((s) => ({
          id: s.id,
          title: s.title,
          frame: s.frame,
          wardrobe: s.wardrobe,
          mood: s.mood,
        })),
        timing: plan.map((p) => ({
          id: p.shot.id,
          start: Number(p.start.toFixed(2)),
          end: Number(p.end.toFixed(2)),
          section: assignment[p.shot.id],
        })),
      });
      setNodes((prev) =>
        prev.map((n) => {
          const hit = res.nodes.find((r) => r.id === n.id);
          if (!hit) return n;
          const next = { ...n };
          if (hit.text?.trim() && (n.kind === "prompt" || n.kind === "model" || n.kind === "audio")) {
            next.text = hit.text;
            pushVersion(`flow:${flow.id}:${n.id}`, {
              text: hit.text,
              source: "brain",
              label: `Brain · timed to ${audioName || "deck order"}`,
            });
          }
          if (hit.rows?.length && n.rows) next.rows = hit.rows;
          return next;
        }),
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : "Auto-populate failed");
    } finally {
      setAutoBusy(false);
    }
  };

  const run = async (override?: string) => {
    if (busy) return;
    setBusy(true);
    setError(null);
    setPreview(null);
    setIsFinal(false);
    try {
      const references = await loadIdentityReferences(IDENTITY_REFS.map((r) => r.url));
      const prompt = [
        withIdentityLock(override ?? composedPrompt(), "strict", references.length),
        seedLine(),
      ]
        .filter(Boolean)
        .join("\n\n");
      await streamImage(
        "/api/generate-shot",
        prompt,
        (dataUrl, final) => {
          setPreview(dataUrl);
          setIsFinal(final);
        },
        references,
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : "Flow run failed");
    } finally {
      setBusy(false);
    }
  };


  const addToDeck = () => {
    if (!preview) return;
    const id = `F${Date.now().toString().slice(-4)}`;
    const shot: Shot = {
      id,
      title: flow.label,
      type: "flow output",
      image: preview,
      alt: `${flow.label} generated frame`,
      frame: "Flow generated",
      wardrobe: "Locked wardrobe",
      mood: flow.tags.join(" · "),
      note: flow.outcome,
      variants: [
        { image: preview, label: "Flow", frame: "Flow generated", wardrobe: "Locked wardrobe" },
      ],
    };
    onAdd(shot);
  };

  return (
    <div className="fl-panel">
      <div className="fl-panel-head">
        <div>
          <h3 className="fl-panel-title">{flow.label}</h3>
          <p className="fl-panel-blurb">{flow.blurb}</p>
          <p className="fl-panel-outcome">→ {flow.outcome}</p>
        </div>
        <div className="dir-board-actions">
          <button type="button" className="dir-btn dir-btn-ghost" onClick={autoPopulate} disabled={autoBusy}>
            {autoBusy ? "Optimizing…" : "Batch Optimize"}
          </button>
          {flow.runnable && (
            <button
              type="button"
              className="dir-btn dir-btn-primary"
              onClick={() => run()}
              disabled={busy}
            >
              {busy ? "Running…" : "Generate Sequence"}
            </button>
          )}

          {flow.handoff === "preview" && (
            <button type="button" className="dir-btn dir-btn-primary" onClick={onOpenPreview}>
              Open Preview
            </button>
          )}
        </div>
      </div>

      <div className="fl-canvas">
        {nodes.map((node, i) => (
          <div className="fl-node-row" key={node.id}>
            <article className={`fl-node fl-node-${node.kind}`}>
              <header className="fl-node-head">{node.title}</header>

              {node.kind === "image" && (
                <div className="fl-node-body">
                  <img className="fl-node-img" src={slots[node.id]} alt="flow demo input" />
                  <div className="fl-node-row-btns">
                    <label className="fl-mini-btn">
                      Replace
                      <input
                        type="file"
                        accept="image/*"
                        hidden
                        onChange={(e) => {
                          const f = e.target.files?.[0];
                          if (f) setSlots((p) => ({ ...p, [node.id]: URL.createObjectURL(f) }));
                        }}
                      />
                    </label>
                    <button
                      type="button"
                      className="fl-mini-btn"
                      onClick={() =>
                        setSlots((p) => {
                          const cur = demoImages.indexOf(p[node.id]);
                          return { ...p, [node.id]: demoImages[(cur + 1) % demoImages.length] };
                        })
                      }
                    >
                      Use next moodboard frame
                    </button>
                  </div>
                </div>
              )}

              {node.kind === "iterator" && (
                <div className="fl-node-body">
                  {node.demo != null && (
                    <div className="fl-iter-imgs">
                      {demoImages.slice(0, 4).map((src) => (
                        <img key={src} src={src} alt="" />
                      ))}
                    </div>
                  )}
                  {node.rows?.map((r, ri) => (
                    <input
                      key={ri}
                      className="fl-row-input"
                      value={r}
                      onChange={(e) => setRow(node.id, ri, e.target.value)}
                    />
                  ))}
                </div>
              )}

              {(node.kind === "prompt" || (node.kind === "model" && node.text)) && (
                <div className="fl-node-body">
                  <textarea
                    className="fl-prompt"
                    value={node.text}
                    rows={7}
                    onChange={(e) => setText(node.id, e.target.value)}
                  />
                  <PromptHistory
                    storeKey={`flow:${flow.id}:${node.id}`}
                    current={node.text ?? ""}
                    busy={busy}
                    onRestore={(v) => setText(node.id, v.text)}
                    onRerun={flow.runnable ? (v) => run(v.text) : undefined}
                  />
                </div>
              )}


              {node.kind === "audio" && (
                <div className="fl-node-body">
                  <div className="fl-wave" aria-hidden>
                    {Array.from({ length: 42 }).map((_, k) => (
                      <span key={k} style={{ height: `${18 + ((k * 37) % 60)}%` }} />
                    ))}
                  </div>
                  <p className="fl-node-note">{node.text}</p>
                </div>
              )}

              {node.kind === "output" && <div className="fl-node-body fl-node-canvasish" />}

              {node.meta && (
                <footer className="fl-node-meta">
                  {node.meta.map((m) => (
                    <span key={m}>{m}</span>
                  ))}
                </footer>
              )}
            </article>
            {i < nodes.length - 1 && <span className="fl-link" aria-hidden />}
          </div>
        ))}
      </div>

      {(preview || error) && (
        <div className="fl-result">
          {error && <p className="fl-error">{error}</p>}
          {preview && (
            <>
              <img className={isFinal ? "fl-result-img" : "fl-result-img fl-blur"} src={preview} alt="Flow result" />
              <div className="fl-result-actions">
                <button type="button" className="pv-btn pv-btn-primary" onClick={addToDeck} disabled={!isFinal}>
                  Add to deck
                </button>
                <a className="pv-btn" href={preview} download={`${flow.id}.png`}>
                  Download
                </a>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}
