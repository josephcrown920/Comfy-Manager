#!/usr/bin/env node
/**
 * Aurora GPU worker.
 *
 * Registers this machine with the studio, polls for queued render jobs
 * (Seedance 2.5 / LTX / LTX-2), runs your local render command, and posts the
 * resulting video URL back.
 *
 * Usage:
 *   node cli/aurora-worker.mjs --api https://your-app.lovable.app \
 *     --name my-4090 --gpu "RTX 4090" --models seedance-2.5,ltx-video --run ./render.sh
 *
 * Your --run command receives the job as JSON on stdin and must print the
 * final video URL (or a local path you have already uploaded) on stdout.
 */
import { spawn } from "node:child_process";

function arg(name, fallback) {
  const i = process.argv.indexOf(`--${name}`);
  return i > -1 && process.argv[i + 1] ? process.argv[i + 1] : fallback;
}

const API = (arg("api", process.env.AURORA_API) || "").replace(/\/$/, "");
const NAME = arg("name", `worker-${process.pid}`);
const GPU = arg("gpu", "unknown");
const MODELS = arg("models", "seedance-2.5,ltx-video,ltx-2")
  .split(",")
  .map((m) => m.trim())
  .filter(Boolean);
const RUN = arg("run", "");
const INTERVAL = Number(arg("interval", "5")) * 1000;

if (!API) {
  console.error("Missing --api <studio url>");
  process.exit(1);
}
if (!RUN) {
  console.error("Missing --run <render command>");
  process.exit(1);
}

async function post(path, body) {
  const res = await fetch(`${API}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`${path} -> ${res.status} ${await res.text().catch(() => "")}`);
  return res.json();
}

function render(job) {
  return new Promise((resolve, reject) => {
    const child = spawn(RUN, { shell: true });
    let out = "";
    let err = "";
    child.stdout.on("data", (d) => (out += d.toString()));
    child.stderr.on("data", (d) => (err += d.toString()));
    child.on("error", reject);
    child.on("close", (code) => {
      if (code !== 0) return reject(new Error(err.trim() || `render exited with ${code}`));
      resolve(out.trim().split("\n").pop().trim());
    });
    child.stdin.write(JSON.stringify(job));
    child.stdin.end();
  });
}

let workerId = null;

async function registerWorker() {
  const { worker } = await post("/api/public/gpu/register", {
    name: NAME,
    gpu: GPU,
    models: MODELS,
    ...(workerId ? { worker_id: workerId } : {}),
  });
  workerId = worker.id;
  console.log(`registered as ${NAME} (${workerId})`);
}

async function tick() {
  const { job } = await post("/api/public/gpu/claim", { worker_id: workerId, models: MODELS });
  if (!job) return;
  console.log(`claimed job ${job.id} (${job.model})`);
  try {
    const output_url = await render(job);
    if (!/^https?:\/\//.test(output_url)) throw new Error(`render printed no URL: ${output_url}`);
    await post("/api/public/gpu/complete", { job_id: job.id, worker_id: workerId, output_url });
    console.log(`completed job ${job.id}`);
  } catch (e) {
    await post("/api/public/gpu/complete", {
      job_id: job.id,
      worker_id: workerId,
      error: String(e.message ?? e).slice(0, 2000),
    }).catch(() => {});
    console.error(`job ${job.id} failed:`, e.message ?? e);
  }
}

await registerWorker();
setInterval(() => registerWorker().catch(() => {}), 60_000);

for (;;) {
  await tick().catch((e) => console.error("poll error:", e.message ?? e));
  await new Promise((r) => setTimeout(r, INTERVAL));
}