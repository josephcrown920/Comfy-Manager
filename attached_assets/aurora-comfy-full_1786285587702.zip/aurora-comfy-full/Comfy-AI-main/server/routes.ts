import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertGeneratedImageSchema } from "@shared/schema";

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Generate Image endpoint
  app.post("/api/generate", async (req, res) => {
    try {
      const { prompt, seed } = req.body;

      if (!prompt || typeof prompt !== "string") {
        return res.status(400).json({ error: "prompt is required" });
      }

      let imageUrl = "";

      // Use OpenAI DALL-E if API key is available
      if (OPENAI_API_KEY) {
        try {
          const response = await fetch("https://api.openai.com/v1/images/generations", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${OPENAI_API_KEY}`,
            },
            body: JSON.stringify({
              model: "dall-e-3",
              prompt: prompt,
              n: 1,
              size: "1024x1024",
            }),
          });

          if (!response.ok) {
            const error = await response.json();
            console.error("OpenAI API error:", error);
            throw new Error(`OpenAI API error: ${error.error?.message || "Unknown error"}`);
          }

          const data = await response.json();
          imageUrl = data.data[0].url;
          console.log("✅ Generated image via OpenAI DALL-E");
        } catch (error) {
          console.error("OpenAI generation failed, using fallback:", error);
          // Fallback to mock image if OpenAI fails
          imageUrl = generateMockImage(prompt);
        }
      } else {
        // Fallback to mock image if no API key
        imageUrl = generateMockImage(prompt);
      }

      const image = await storage.createGeneratedImage({
        prompt,
        imageUrl,
        seed: seed || 12345,
      });

      res.json(image);
    } catch (error) {
      console.error("Error generating image:", error);
      res.status(500).json({ error: "Failed to generate image" });
    }
  });

  function generateMockImage(prompt: string): string {
    return `data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='512' height='512'%3E%3Cdefs%3E%3ClinearGradient id='grad' x1='0%25' y1='0%25' x2='100%25' y2='100%25'%3E%3Cstop offset='0%25' style='stop-color:rgb(6,182,212);stop-opacity:0.3' /%3E%3Cstop offset='100%25' style='stop-color:rgb(37,99,235);stop-opacity:0.3' /%3E%3C/linearGradient%3E%3C/defs%3E%3Crect width='512' height='512' fill='%23020408'/%3E%3Crect width='512' height='512' fill='url(%23grad)'/%3E%3Ccircle cx='256' cy='256' r='100' fill='%2306b6d4' opacity='0.2'/%3E%3Ccircle cx='150' cy='180' r='60' fill='%232563eb' opacity='0.15'/%3E%3Ccircle cx='380' cy='340' r='80' fill='%236366f1' opacity='0.1'/%3E%3Ctext x='256' y='256' font-family='monospace' font-size='12' fill='%2306b6d4' text-anchor='middle' opacity='0.5'%3EMock: ${encodeURIComponent(prompt.substring(0, 20))}%3C/text%3E%3C/svg%3E`;
  }

  // Get generated images
  app.get("/api/images", async (req, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const images = await storage.getGeneratedImages(limit);
      res.json(images);
    } catch (error) {
      console.error("Error fetching images:", error);
      res.status(500).json({ error: "Failed to fetch images" });
    }
  });

  // Get single image
  app.get("/api/images/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const image = await storage.getGeneratedImage(id);

      if (!image) {
        return res.status(404).json({ error: "Image not found" });
      }

      res.json(image);
    } catch (error) {
      console.error("Error fetching image:", error);
      res.status(500).json({ error: "Failed to fetch image" });
    }
  });

  return httpServer;
}
