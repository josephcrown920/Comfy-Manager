python3 -m venv .venv
source .venv/bin/activate

pip install --upgrade pip
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
pip install numpy Pillow opencv-python moviepy

pip install safetensors transformers accelerate
pip install comfyui gradio tqdm

mkdir -p ComfyUI models projects outputs inputs

MODEL_DIR="models/stable_diffusion_v1_5"
if [ ! -d "$MODEL_DIR" ]; then
    python3 - <<PYTHON
from diffusers import StableDiffusionPipeline
pipe = StableDiffusionPipeline.from_pretrained("runwayml/stable-diffusion-v1-5", torch_dtype="auto")
pipe.save_pretrained("$MODEL_DIR")
PYTHON
fi

cat <<EOL > comfy_launch.py
import comfyui
import os

os.environ["COMFYUI_MODELS_DIR"] = "./models"
os.environ["COMFYUI_OUTPUT_DIR"] = "./outputs"

# Run web UI automatically without prompts
comfyui.launch(ui="web", port=7860, gpu=True)
EOL

cat <<EOL > generate_drill_still.py
from diffusers import StableDiffusionPipeline
import torch

device = "cuda" if torch.cuda.is_available() else "cpu"

pipe = StableDiffusionPipeline.from_pretrained(
    "runwayml/stable-diffusion-v1-5",
    torch_dtype=torch.float16
).to(device)

prompt = "dark drill music video still, cinematic lighting, urban night, smoke"
image = pipe(prompt, seed=12345).images[0]

image.save("frame1.png")
print("✅ Frame generated: frame1.png")
EOL