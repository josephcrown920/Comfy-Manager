# Aurora ComfyUI GPU Stack

This bundle contains the Core Engine app and Aurora's runnable free-GPU worker stack.

## Included

- `core-engine/Comfy-AI-main/` — the uploaded Core Engine / ComfyUI deployment app
- `workers/kaggle/` — Kaggle notebook and launcher for registering a ComfyUI GPU worker
- `workers/colab/` — Google Colab notebook and launcher for registering a ComfyUI GPU worker
- `workers/comfyui/` — ComfyUI worker launcher
- `notebooks/` — hybrid inference notebook
- `docs/` — swarm architecture and capability notes

## Capabilities

The worker swarm is designed for ComfyUI-backed image, video, motion, and lip-sync jobs. Launchers register workers with Aurora after health checks and advertise only the capabilities available on that session.

## Before running

Set these values in the notebook/runtime secrets; do not commit them into the ZIP:

- `AURORA_URL`
- `AURORA_REGISTER_KEY`
- `NGROK_AUTHTOKEN`
- Optional `NGROK_STATIC_DOMAIN`

The notebook launchers install dependencies, start ComfyUI, open the tunnel, wait for `/health`, and register the worker. Free GPU sessions can time out or disconnect, so relaunching the notebook re-registers the worker.

## Quick start

1. Open the Kaggle or Colab notebook from its folder.
2. Add the runtime secrets above.
3. Select a GPU runtime.
4. Run all cells.
5. Confirm the worker appears in Aurora Admin → Workers.
6. Submit supported jobs from Aurora; the orchestrator routes to an available worker.

Never put real API keys or worker tokens in the notebook source or this ZIP.
