import { createFileRoute } from "@tanstack/react-router";
import { StoryboardGallery } from "@/features/storyboard/StoryboardGallery";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Dynamic Storyboard — AI Music Video Shot Deck" },
      {
        name: "description",
        content:
          "Ten cinematic storyboard frames blending neon Miami, studio portraiture, streetwear fashion, and performance energy.",
      },
      { property: "og:title", content: "Music Video Storyboard Shots" },
      {
        property: "og:description",
        content:
          "Ten cinematic storyboard frames blending neon Miami, studio portraiture, streetwear fashion, and performance energy.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return <StoryboardGallery />;
}
