import { useMemo, useRef, useState } from "react";
import {
  DndContext,
  DragOverlay,
  PointerSensor,
  KeyboardSensor,
  closestCenter,
  useSensor,
  useSensors,
  type DragEndEvent,
  type DragOverEvent,
  type DragStartEvent,
} from "@dnd-kit/core";
import {
  SortableContext,
  arrayMove,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import type { Shot } from "./shots";

import { SECTIONS, useTimeline, type SectionId } from "./timelineStore";

type Assignment = Record<string, SectionId>;
type VariantMap = Record<string, number>;
type TimestampMap = Record<string, number>;

const formatTime = (s: number) => {
  if (!Number.isFinite(s) || s < 0) s = 0;
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return `${m}:${sec.toString().padStart(2, "0")}`;
};

export function StoryboardSequencer({ shots }: { shots: Shot[] }) {
  const {
    order,
    setOrder,
    assignment,
    setAssignment,
    variantIdx,
    setVariantIdx,
    timestamps,
    setTimestamps,
    audioSrc,
    audioName,
    setAudio,
    reset: resetAll,
  } = useTimeline();

  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [activeId, setActiveId] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement>(null);

  const shotById = useMemo(() => new Map(shots.map((s) => [s.id, s])), [shots]);


  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  const bySection = useMemo(() => {
    const out: Record<SectionId, string[]> = {
      intro: [],
      verse: [],
      chorus: [],
      bridge: [],
      outro: [],
    };
    order.forEach((id) => {
      const sec = assignment[id] ?? "verse";
      out[sec].push(id);
    });
    return out;
  }, [order, assignment]);

  const findSection = (id: string): SectionId | undefined => {
    if (SECTIONS.some((s) => s.id === id)) return id as SectionId;
    return assignment[id];
  };

  const handleDragStart = (e: DragStartEvent) => setActiveId(String(e.active.id));

  const handleDragOver = (e: DragOverEvent) => {
    const { active, over } = e;
    if (!over) return;
    const activeId = String(active.id);
    const overId = String(over.id);
    const activeSection = findSection(activeId);
    const overSection = findSection(overId);
    if (!activeSection || !overSection || activeSection === overSection) return;
    setAssignment((prev) => ({ ...prev, [activeId]: overSection }));
  };

  const handleDragEnd = (e: DragEndEvent) => {
    setActiveId(null);
    const { active, over } = e;
    if (!over) return;
    const activeId = String(active.id);
    const overId = String(over.id);
    if (activeId === overId) return;
    // Reorder within combined list to preserve relative order within section
    setOrder((prev) => {
      const from = prev.indexOf(activeId);
      let to = prev.indexOf(overId);
      if (to === -1) {
        // dropped on section container: place at end of that section
        const sec = overId as SectionId;
        const secItems = prev.filter((id) => (assignment[id] ?? "verse") === sec && id !== activeId);
        const lastInSec = secItems[secItems.length - 1];
        to = lastInSec ? prev.indexOf(lastInSec) + 1 : prev.length;
      }
      if (from === -1 || to === -1) return prev;
      return arrayMove(prev, from, to > from ? to : to);
    });
  };

  const onAudioFile = (file: File) => {
    setAudio(file);
    setDuration(0);
    setCurrentTime(0);
  };


  const setStampToCurrent = (shotId: string) => {
    const a = audioRef.current;
    if (!a) return;
    setTimestamps((prev) => ({ ...prev, [shotId]: a.currentTime }));
  };

  const seekTo = (t: number) => {
    const a = audioRef.current;
    if (!a) return;
    a.currentTime = t;
    a.play().catch(() => {});
  };

  const timelineMarkers = useMemo(() => {
    if (!duration) return [];
    return Object.entries(timestamps)
      .filter(([, t]) => Number.isFinite(t))
      .map(([id, t]) => ({ id, t, pct: Math.min(100, (t / duration) * 100) }))
      .sort((a, b) => a.t - b.t);
  }, [timestamps, duration]);



  return (
    <section className="storyboard-sequencer" aria-labelledby="sequencer-title">
      <div className="storyboard-section-head">
        <div className="grid gap-2">
          <h2 id="sequencer-title" className="storyboard-section-title">
            Sequencer & audio timeline
          </h2>
          <p className="storyboard-section-copy">
            Drag shots between song sections, toggle alternate outfits/angles, and stamp each frame to your track.
          </p>
        </div>
        <button type="button" className="seq-btn seq-btn-ghost" onClick={resetAll}>
          Reset
        </button>
      </div>

      {/* Audio timeline */}
      <div className="seq-audio-card">
        <div className="seq-audio-head">
          <label className="seq-btn seq-btn-primary">
            {audioSrc ? "Change track" : "Load audio track"}
            <input
              type="file"
              accept="audio/*"
              hidden
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) onAudioFile(f);
              }}
            />
          </label>
          <div className="seq-audio-name">{audioName || "No track loaded — MP3/WAV supported."}</div>
          <div className="seq-audio-time">
            {formatTime(currentTime)} / {formatTime(duration)}
          </div>
        </div>

        {audioSrc && (
          <audio
            ref={audioRef}
            src={audioSrc}
            controls
            className="seq-audio-player"
            onLoadedMetadata={(e) => setDuration(e.currentTarget.duration || 0)}
            onTimeUpdate={(e) => setCurrentTime(e.currentTarget.currentTime)}
          />
        )}

        <div className="seq-timeline" role="group" aria-label="Shot timestamps on track">
          <div className="seq-timeline-track">
            <div
              className="seq-timeline-progress"
              style={{ width: duration ? `${(currentTime / duration) * 100}%` : "0%" }}
            />
            {timelineMarkers.map((m) => {
              const shot = shotById.get(m.id);
              if (!shot) return null;
              return (
                <button
                  key={m.id}
                  type="button"
                  className="seq-timeline-marker"
                  style={{ left: `${m.pct}%` }}
                  onClick={() => seekTo(m.t)}
                  title={`Shot ${shot.id} — ${shot.title} · ${formatTime(m.t)}`}
                  aria-label={`Jump to shot ${shot.id} at ${formatTime(m.t)}`}
                >
                  <span className="seq-timeline-marker-label">{shot.id}</span>
                </button>
              );
            })}
          </div>
          {!audioSrc && (
            <p className="seq-timeline-empty">Load a track to stamp shots to timestamps.</p>
          )}
          {audioSrc && timelineMarkers.length === 0 && (
            <p className="seq-timeline-empty">
              Play the track and press <em>Stamp @ now</em> on any shot below to pin it here.
            </p>
          )}
        </div>
      </div>

      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragStart={handleDragStart}
        onDragOver={handleDragOver}
        onDragEnd={handleDragEnd}
      >
        <div className="seq-sections">
          {SECTIONS.map((section) => (
            <SectionColumn
              key={section.id}
              section={section}
              itemIds={bySection[section.id]}
              shotById={shotById}
              variantIdx={variantIdx}
              setVariantIdx={setVariantIdx}
              timestamps={timestamps}
              hasAudio={!!audioSrc}
              onStamp={setStampToCurrent}
              onClearStamp={(id) =>
                setTimestamps((prev) => {
                  const { [id]: _drop, ...rest } = prev;
                  return rest;
                })
              }
              onSeek={seekTo}
            />
          ))}
        </div>

        <DragOverlay>
          {activeId && shotById.get(activeId) ? (
            <ShotCard
              shot={shotById.get(activeId)!}
              variantIndex={variantIdx[activeId] ?? 0}
              onCycleVariant={() => {}}
              timestamp={timestamps[activeId]}
              hasAudio={false}
              onStamp={() => {}}
              onClearStamp={() => {}}
              onSeek={() => {}}
              dragging
            />
          ) : null}
        </DragOverlay>
      </DndContext>
    </section>
  );
}

function SectionColumn({
  section,
  itemIds,
  shotById,
  variantIdx,
  setVariantIdx,
  timestamps,
  hasAudio,
  onStamp,
  onClearStamp,
  onSeek,
}: {
  section: { id: SectionId; label: string; hint: string };
  itemIds: string[];
  shotById: Map<string, Shot>;
  variantIdx: VariantMap;
  setVariantIdx: React.Dispatch<React.SetStateAction<VariantMap>>;
  timestamps: TimestampMap;
  hasAudio: boolean;
  onStamp: (id: string) => void;
  onClearStamp: (id: string) => void;
  onSeek: (t: number) => void;
}) {
  const { setNodeRef, isOver } = useDroppableSection(section.id);
  return (
    <div className={`seq-section ${isOver ? "seq-section-over" : ""}`} ref={setNodeRef}>
      <div className="seq-section-head">
        <span className={`seq-section-badge seq-badge-${section.id}`}>{section.label}</span>
        <span className="seq-section-hint">{section.hint}</span>
        <span className="seq-section-count">{itemIds.length}</span>
      </div>

      <SortableContext items={itemIds} strategy={verticalListSortingStrategy}>
        <div className="seq-section-list">
          {itemIds.length === 0 && (
            <div className="seq-empty">Drop shots here for the {section.label.toLowerCase()}.</div>
          )}
          {itemIds.map((id) => {
            const shot = shotById.get(id);
            if (!shot) return null;
            return (
              <SortableShot
                key={id}
                shot={shot}
                variantIndex={variantIdx[id] ?? 0}
                onCycleVariant={() =>
                  setVariantIdx((prev) => ({
                    ...prev,
                    [id]: ((prev[id] ?? 0) + 1) % shot.variants.length,
                  }))
                }
                timestamp={timestamps[id]}
                hasAudio={hasAudio}
                onStamp={() => onStamp(id)}
                onClearStamp={() => onClearStamp(id)}
                onSeek={onSeek}
              />
            );
          })}
        </div>
      </SortableContext>
    </div>
  );
}

// Section container is itself a droppable via useSortable-compatible id
import { useDroppable } from "@dnd-kit/core";
function useDroppableSection(id: SectionId) {
  return useDroppable({ id });
}

function SortableShot(props: {
  shot: Shot;
  variantIndex: number;
  onCycleVariant: () => void;
  timestamp: number | undefined;
  hasAudio: boolean;
  onStamp: () => void;
  onClearStamp: () => void;
  onSeek: (t: number) => void;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: props.shot.id,
  });
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.35 : 1,
  };
  return (
    <div ref={setNodeRef} style={style} {...attributes} {...listeners}>
      <ShotCard {...props} />
    </div>
  );
}

function ShotCard({
  shot,
  variantIndex,
  onCycleVariant,
  timestamp,
  hasAudio,
  onStamp,
  onClearStamp,
  onSeek,
  dragging,
}: {
  shot: Shot;
  variantIndex: number;
  onCycleVariant: () => void;
  timestamp: number | undefined;
  hasAudio: boolean;
  onStamp: () => void;
  onClearStamp: () => void;
  onSeek: (t: number) => void;
  dragging?: boolean;
}) {
  const variant = shot.variants[variantIndex] ?? shot.variants[0];
  const hasMultiple = shot.variants.length > 1;
  return (
    <article className={`seq-card ${dragging ? "seq-card-drag" : ""}`}>
      <div className="seq-card-media">
        <img src={variant.image} alt={shot.alt} loading="lazy" />
        <div className="seq-card-drag-handle" aria-hidden>⋮⋮</div>
        <span className="seq-card-shot-num">Shot {shot.id}</span>
        {hasMultiple && (
          <button
            type="button"
            className="seq-card-variant-btn"
            onPointerDown={(e) => e.stopPropagation()}
            onClick={(e) => {
              e.stopPropagation();
              onCycleVariant();
            }}
            title="Swap outfit / angle"
          >
            {variant.label} · {variantIndex + 1}/{shot.variants.length} ⇄
          </button>
        )}
      </div>
      <div className="seq-card-body">
        <h3 className="seq-card-title">{shot.title}</h3>
        <p className="seq-card-meta">{variant.frame}</p>
        <p className="seq-card-meta seq-card-meta-muted">{variant.wardrobe}</p>

        <div className="seq-card-actions" onPointerDown={(e) => e.stopPropagation()}>
          {timestamp != null ? (
            <>
              <button
                type="button"
                className="seq-btn seq-btn-chip"
                onClick={(e) => {
                  e.stopPropagation();
                  onSeek(timestamp);
                }}
                title="Jump to this timestamp"
              >
                ▶ {formatTime(timestamp)}
              </button>
              <button
                type="button"
                className="seq-btn seq-btn-ghost-sm"
                onClick={(e) => {
                  e.stopPropagation();
                  onClearStamp();
                }}
              >
                clear
              </button>
            </>
          ) : (
            <button
              type="button"
              className="seq-btn seq-btn-chip"
              disabled={!hasAudio}
              onClick={(e) => {
                e.stopPropagation();
                onStamp();
              }}
              title={hasAudio ? "Stamp this shot at current audio time" : "Load a track first"}
            >
              ⏱ Stamp @ now
            </button>
          )}
        </div>
      </div>
    </article>
  );
}
