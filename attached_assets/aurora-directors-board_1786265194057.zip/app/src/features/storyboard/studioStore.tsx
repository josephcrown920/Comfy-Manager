import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { DEFAULT_BRAIN_MODEL, DEFAULT_VID_MODEL } from "./models";


/** ---------------------------------------------------------------
 * Studio store — storyboards (boards), seed vision, and prompt
 * version history for every shot and every flow node.
 * ---------------------------------------------------------------*/

export type PromptVersion = {
  id: string;
  text: string;
  negative?: string;
  source: "brain" | "manual" | "preset";
  label: string;
  at: number;
};

export type Board = {
  id: string;
  name: string;
  createdAt: number;
  /** empty = start from scratch, "deck" = seeded with the reference 10 shots */
  base: "deck" | "blank";
  seed: number | null;
  history: Record<string, PromptVersion[]>;
};

export type Settings = {
  /** id of the reasoning model driving the brain */
  brainModel: string;
  /** id of the image/video model driving the vid agent */
  vidModel: string;
  /** shot id -> replacement image url / data url (admin photo swap) */
  imageOverrides: Record<string, string>;
};

type Ctx = {
  boards: Board[];
  board: Board;
  createBoard: (name: string, base: "deck" | "blank") => void;
  switchBoard: (id: string) => void;
  renameBoard: (id: string, name: string) => void;
  deleteBoard: (id: string) => void;
  seed: number | null;
  setSeed: (seed: number | null) => void;
  randomizeSeed: () => void;
  seedLine: () => string;
  history: Record<string, PromptVersion[]>;
  versions: (key: string) => PromptVersion[];
  pushVersion: (key: string, v: Omit<PromptVersion, "id" | "at">) => PromptVersion;
  updateVersion: (key: string, id: string, patch: Partial<PromptVersion>) => void;
  removeVersion: (key: string, id: string) => void;
  settings: Settings;
  setBrainModel: (id: string) => void;
  setVidModel: (id: string) => void;
  setImageOverride: (shotId: string, url: string | null) => void;
  resetImageOverrides: () => void;
};


const StudioCtx = createContext<Ctx | null>(null);
const STORAGE_KEY = "storyboard.studio.v1";

const newId = () => Math.random().toString(36).slice(2, 9);

function makeBoard(name: string, base: "deck" | "blank"): Board {
  return {
    id: newId(),
    name,
    base,
    createdAt: Date.now(),
    seed: Math.floor(Math.random() * 1_000_000),
    history: {},
  };
}

type Persisted = { boards: Board[]; activeId: string; settings?: Settings };

const DEFAULT_SETTINGS: Settings = {
  brainModel: DEFAULT_BRAIN_MODEL,
  vidModel: DEFAULT_VID_MODEL,
  imageOverrides: {},
};

function load(): Persisted | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Persisted;
    if (!parsed.boards?.length) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function StudioProvider({ children }: { children: ReactNode }) {
  const [boards, setBoards] = useState<Board[]>(() => [makeBoard("Music video — main deck", "deck")]);
  const [activeId, setActiveId] = useState<string>(() => "");
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    const saved = load();
    if (saved) {
      setBoards(saved.boards);
      setActiveId(saved.activeId);
      if (saved.settings) setSettings({ ...DEFAULT_SETTINGS, ...saved.settings });
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    try {
      window.localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({
          boards,
          activeId: activeId || boards[0].id,
          settings,
        } satisfies Persisted),
      );
    } catch {
      /* storage full or blocked */
    }
  }, [boards, activeId, settings, hydrated]);

  const setBrainModel = useCallback(
    (id: string) => setSettings((s) => ({ ...s, brainModel: id })),
    [],
  );
  const setVidModel = useCallback((id: string) => setSettings((s) => ({ ...s, vidModel: id })), []);
  const setImageOverride = useCallback((shotId: string, url: string | null) => {
    setSettings((s) => {
      const next = { ...s.imageOverrides };
      if (url) next[shotId] = url;
      else delete next[shotId];
      return { ...s, imageOverrides: next };
    });
  }, []);
  const resetImageOverrides = useCallback(
    () => setSettings((s) => ({ ...s, imageOverrides: {} })),
    [],
  );


  const board = useMemo(
    () => boards.find((b) => b.id === activeId) ?? boards[0],
    [boards, activeId],
  );

  const patchBoard = useCallback(
    (id: string, patch: (b: Board) => Board) =>
      setBoards((prev) => prev.map((b) => (b.id === id ? patch(b) : b))),
    [],
  );

  const createBoard = useCallback((name: string, base: "deck" | "blank") => {
    const next = makeBoard(name.trim() || "Untitled storyboard", base);
    setBoards((prev) => [...prev, next]);
    setActiveId(next.id);
  }, []);

  const renameBoard = useCallback(
    (id: string, name: string) => patchBoard(id, (b) => ({ ...b, name })),
    [patchBoard],
  );

  const deleteBoard = useCallback(
    (id: string) =>
      setBoards((prev) => {
        if (prev.length === 1) return prev;
        const next = prev.filter((b) => b.id !== id);
        setActiveId((cur) => (cur === id ? next[0].id : cur));
        return next;
      }),
    [],
  );

  const setSeed = useCallback(
    (seed: number | null) => patchBoard(board.id, (b) => ({ ...b, seed })),
    [board.id, patchBoard],
  );

  const randomizeSeed = useCallback(
    () => setSeed(Math.floor(Math.random() * 1_000_000)),
    [setSeed],
  );

  const seedLine = useCallback(
    () =>
      board.seed == null
        ? ""
        : `SEED VISION: ${board.seed}. Treat this seed as the deterministic look-key for this storyboard — reuse the same grade, grain, lens character and face rendering across every frame generated under it.`,
    [board.seed],
  );

  const pushVersion = useCallback(
    (key: string, v: Omit<PromptVersion, "id" | "at">) => {
      const version: PromptVersion = { ...v, id: newId(), at: Date.now() };
      patchBoard(board.id, (b) => ({
        ...b,
        history: { ...b.history, [key]: [version, ...(b.history[key] ?? [])].slice(0, 25) },
      }));
      return version;
    },
    [board.id, patchBoard],
  );

  const updateVersion = useCallback(
    (key: string, id: string, patch: Partial<PromptVersion>) =>
      patchBoard(board.id, (b) => ({
        ...b,
        history: {
          ...b.history,
          [key]: (b.history[key] ?? []).map((v) => (v.id === id ? { ...v, ...patch } : v)),
        },
      })),
    [board.id, patchBoard],
  );

  const removeVersion = useCallback(
    (key: string, id: string) =>
      patchBoard(board.id, (b) => ({
        ...b,
        history: { ...b.history, [key]: (b.history[key] ?? []).filter((v) => v.id !== id) },
      })),
    [board.id, patchBoard],
  );

  const versions = useCallback((key: string) => board.history[key] ?? [], [board.history]);

  const value: Ctx = {
    boards,
    board,
    createBoard,
    switchBoard: setActiveId,
    renameBoard,
    deleteBoard,
    seed: board.seed,
    setSeed,
    randomizeSeed,
    seedLine,
    history: board.history,
    versions,
    pushVersion,
    updateVersion,
    removeVersion,
    settings,
    setBrainModel,
    setVidModel,
    setImageOverride,
    resetImageOverrides,
  };


  return <StudioCtx.Provider value={value}>{children}</StudioCtx.Provider>;
}

export function useStudio() {
  const ctx = useContext(StudioCtx);
  if (!ctx) throw new Error("useStudio must be used inside StudioProvider");
  return ctx;
}
