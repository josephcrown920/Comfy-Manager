import { useState } from "react";
import { PRESETS, CAMERAS, buildPrompt, type LockLevel } from "./characterLock";
import { IDENTITY_REFS, LOCK_STRENGTHS, loadIdentityReferences } from "./identityRefs";
import { streamImage } from "@/lib/streamImage";
import { useStudio } from "./studioStore";
import { SeedBar } from "./BrainBoard";
import type { Shot } from "./shots";


type Draft = {
  id: string;
  idea: string;
  presetLabel: string;
  camera: string;
  dataUrl: string | null;
  isFinal: boolean;
  error?: string;
};

export function ShotGenerator({ onAdd }: { onAdd: (shot: Shot) => void }) {
  const [idea, setIdea] = useState("");
  const [presetId, setPresetId] = useState(PRESETS[0].id);
  const [camera, setCamera] = useState<string>(CAMERAS[3]);
  const [busy, setBusy] = useState(false);
  const [drafts, setDrafts] = useState<Draft[]>([]);
  const [lock, setLock] = useState<LockLevel>("strict");
  const [refIds, setRefIds] = useState<string[]>(IDENTITY_REFS.map((r) => r.id));
  const { seed, setSeed, randomizeSeed, seedLine } = useStudio();

  const preset = PRESETS.find((p) => p.id === presetId) ?? PRESETS[0];


  const toggleRef = (id: string) =>
    setRefIds((prev) =>
      prev.includes(id) ? (prev.length > 1 ? prev.filter((x) => x !== id) : prev) : [...prev, id],
    );

  const generate = async () => {
    if (busy) return;
    const direction = idea.trim() || preset.hint;
    const draftId = `gen-${Date.now()}`;
    const draft: Draft = {
      id: draftId,
      idea: direction,
      presetLabel: preset.label,
      camera,
      dataUrl: null,
      isFinal: false,
    };
    setDrafts((prev) => [draft, ...prev]);
    setBusy(true);

    try {
      const references = await loadIdentityReferences(
        IDENTITY_REFS.filter((r) => refIds.includes(r.id)).map((r) => r.url),
      );
      await streamImage(
        "/api/generate-shot",
        [
          buildPrompt({
            idea: direction,
            scene: preset.scene,
            camera,
            lock,
            refCount: references.length,
          }),
          seedLine(),
        ]
          .filter(Boolean)
          .join("\n\n"),

        (dataUrl, isFinal) => {
          setDrafts((prev) =>
            prev.map((d) => (d.id === draftId ? { ...d, dataUrl, isFinal } : d)),
          );
        },
        references,
      );
    } catch (err) {
      const message = err instanceof Error ? err.message : "Generation failed";
      setDrafts((prev) => prev.map((d) => (d.id === draftId ? { ...d, error: message } : d)));
    } finally {
      setBusy(false);
    }
  };


  const addToDeck = (draft: Draft) => {
    if (!draft.dataUrl) return;
    const shot: Shot = {
      id: draft.id,
      title: draft.idea.slice(0, 60),
      type: "AI generated",
      image: draft.dataUrl,
      alt: draft.idea,
      frame: draft.camera,
      wardrobe: draft.presetLabel,
      mood: "Consistency-locked avatar",
      note: draft.idea,
      variants: [
        {
          image: draft.dataUrl,
          label: "Generated",
          frame: draft.camera,
          wardrobe: draft.presetLabel,
        },
      ],
    };
    onAdd(shot);
    setDrafts((prev) => prev.filter((d) => d.id !== draft.id));
  };

  return (
    <section className="sb-gen" aria-labelledby="gen-title">
      <div className="sb-gen-head">
        <h2 id="gen-title" className="sb-gen-title">
          AI shot generator
        </h2>
        <p className="sb-gen-copy">
          Every frame is locked to your avatar — red dreads, sculpted red shades, iced chains — and
          the deck&apos;s neon palette, so new shots cut with the existing ten.
        </p>
      </div>

      <SeedBar seed={seed} setSeed={setSeed} randomize={randomizeSeed} />

      <div className="sb-lockbar">

        <div className="sb-lock-col">
          <span className="sb-lock-label">Identity references sent with every render</span>
          <div className="sb-lock-refs">
            {IDENTITY_REFS.map((r) => (
              <button
                key={r.id}
                type="button"
                className={`sb-lock-ref ${refIds.includes(r.id) ? "sb-lock-ref-on" : ""}`}
                onClick={() => toggleRef(r.id)}
                title={r.label}
                aria-pressed={refIds.includes(r.id)}
              >
                <img src={r.url} alt={r.label} loading="lazy" />
                <em>{r.id}</em>
              </button>
            ))}
          </div>
        </div>
        <div className="sb-lock-col">
          <span className="sb-lock-label">Match strength</span>
          <div className="sb-preset-row">
            {LOCK_STRENGTHS.map((s) => (
              <button
                key={s.id}
                type="button"
                title={s.hint}
                className={`sb-chip sb-chip-sm ${s.id === lock ? "sb-chip-on" : ""}`}
                onClick={() => setLock(s.id)}
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="sb-gen-controls">

        <div className="sb-preset-row" role="group" aria-label="Scene preset">
          {PRESETS.map((p) => (
            <button
              key={p.id}
              type="button"
              className={`sb-chip ${p.id === presetId ? "sb-chip-on" : ""}`}
              onClick={() => setPresetId(p.id)}
              title={p.hint}
            >
              {p.label}
            </button>
          ))}
        </div>

        <div className="sb-preset-row" role="group" aria-label="Camera">
          {CAMERAS.map((c) => (
            <button
              key={c}
              type="button"
              className={`sb-chip sb-chip-sm ${c === camera ? "sb-chip-on" : ""}`}
              onClick={() => setCamera(c)}
            >
              {c}
            </button>
          ))}
        </div>

        <div className="sb-gen-input-row">
          <input
            className="sb-input"
            value={idea}
            placeholder={`Describe the shot — e.g. "${preset.hint}"`}
            onChange={(e) => setIdea(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") generate();
            }}
          />
          <button type="button" className="sb-btn-primary" onClick={generate} disabled={busy}>
            {busy ? "Generating…" : "Generate frame"}
          </button>
        </div>
      </div>

      {drafts.length > 0 && (
        <div className="sb-gen-grid">
          {drafts.map((d) => (
            <figure key={d.id} className="sb-gen-card">
              <div className="sb-gen-media">
                {d.dataUrl ? (
                  <img
                    src={d.dataUrl}
                    alt={d.idea}
                    className={d.isFinal ? "sb-gen-img" : "sb-gen-img sb-gen-img-partial"}
                  />
                ) : (
                  <div className="sb-gen-skeleton">{d.error ? "Failed" : "Rendering…"}</div>
                )}
              </div>
              <figcaption className="sb-gen-caption">
                <span className="sb-gen-meta">
                  {d.presetLabel} · {d.camera}
                </span>
                <p className="sb-gen-idea">{d.error ?? d.idea}</p>
                <div className="sb-gen-actions">
                  <button
                    type="button"
                    className="sb-btn-sm"
                    disabled={!d.isFinal}
                    onClick={() => addToDeck(d)}
                  >
                    Add to deck
                  </button>
                  {d.dataUrl && d.isFinal && (
                    <a className="sb-btn-sm sb-btn-ghost" href={d.dataUrl} download={`${d.id}.png`}>
                      Download
                    </a>
                  )}
                  <button
                    type="button"
                    className="sb-btn-sm sb-btn-ghost"
                    onClick={() => setDrafts((prev) => prev.filter((x) => x.id !== d.id))}
                  >
                    Discard
                  </button>
                </div>
              </figcaption>
            </figure>
          ))}
        </div>
      )}
    </section>
  );
}
