import { useState, useRef, useEffect } from "react";
import { Check, Copy, Terminal, ChevronRight, Download, Package, Activity, FileCode, CheckCircle2, Box, Cpu, Music, Camera, Share2, Zap, Sparkles, Send } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useMutation } from "@tanstack/react-query";

const API_BASE = "";
const OPENAI_API_KEY = import.meta.env.VITE_OPENAI_API_KEY || "mock";

const SETUP_STEPS = [
  {
    id: 1,
    title: "Venv Environment",
    description: "Initialize and activate a clean Python virtual environment for total isolation.",
    command: "python3 -m venv .venv\nsource .venv/bin/activate",
    icon: Terminal,
  },
  {
    id: 2,
    title: "GPU Dependencies",
    description: "Install CUDA-optimized PyTorch and essential imaging/video libraries.",
    command: "pip install --upgrade pip\npip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118\npip install numpy Pillow opencv-python moviepy",
    icon: Activity,
  },
  {
    id: 3,
    title: "AI Frameworks",
    description: "Deploy core model handling libraries and ComfyUI/Gradio components.",
    command: "pip install safetensors transformers accelerate\npip install comfyui gradio tqdm",
    icon: Package,
  },
  {
    id: 4,
    title: "Workspace Structure",
    description: "Auto-generate required directory hierarchy for models, projects, and media.",
    command: "mkdir -p ComfyUI models projects outputs inputs",
    icon: Box,
  },
  {
    id: 5,
    title: "Model Acquisition",
    description: "Locally cache Stable Diffusion v1.5 from RunwayML via automated Python fetch.",
    command: "MODEL_DIR=\"models/stable_diffusion_v1_5\"\nif [ ! -d \"$MODEL_DIR\" ]; then\n    python3 - <<PYTHON\nfrom diffusers import StableDiffusionPipeline\npipe = StableDiffusionPipeline.from_pretrained(\"runwayml/stable-diffusion-v1-5\", torch_dtype=\"auto\")\npipe.save_pretrained(\"$MODEL_DIR\")\nPYTHON\nfi",
    icon: Download,
  },
  {
    id: 6,
    title: "Headless Launch",
    description: "Create the ComfyUI bootstrapper script configured for web-headless operation.",
    command: "cat <<EOL > comfy_launch.py\nimport comfyui\nimport os\n\nos.environ[\"COMFYUI_MODELS_DIR\"] = \"./models\"\nos.environ[\"COMFYUI_OUTPUT_DIR\"] = \"./outputs\"\n\n# Run web UI automatically without prompts\ncomfyui.launch(ui=\"web\", port=7860, gpu=True)\nEOL",
    icon: FileCode,
  },
  {
    id: 7,
    title: "Drill Generation",
    description: "Deploy the custom inference script for Dark Drill cinematic still generation.",
    command: "cat <<EOL > generate_drill_still.py\nfrom diffusers import StableDiffusionPipeline\nimport torch\n\ndevice = \"cuda\" if torch.cuda.is_available() else \"cpu\"\n\npipe = StableDiffusionPipeline.from_pretrained(\n    \"runwayml/stable-diffusion-v1-5\",\n    torch_dtype=torch.float16\n).to(device)\n\nprompt = \"dark drill music video still, cinematic lighting, urban night, smoke\"\nimage = pipe(prompt, seed=12345).images[0]\n\nimage.save(\"frame1.png\")\nprint(\"✅ Frame generated: frame1.png\")\nEOL",
    icon: Camera,
  }
];

const SAMPLE_PROMPTS = [
  "dark drill music video still, cinematic lighting, urban night, smoke",
  "cyberpunk neon city, rain-soaked streets, synthwave aesthetic, night",
  "moody underground tunnel, dramatic shadows, blue neon lights flashing",
  "abandoned industrial warehouse, smoke thick in air, red warning lights",
  "dystopian cityscape, flying drones, purple and cyan lighting, dark",
  "futuristic nightclub, laser beams cutting through smoke, intense energy"
];

export default function Home() {
  const [copiedId, setCopiedId] = useState<number | null>(null);
  const [activeStep, setActiveStep] = useState(1);
  const [prompt, setPrompt] = useState("dark drill music video still, cinematic lighting, urban night, smoke");
  const [showPromptPanel, setShowPromptPanel] = useState(false);
  const [images, setImages] = useState<any[]>([]);
  const copyTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Fetch images on component mount
  useEffect(() => {
    const fetchImages = async () => {
      try {
        const res = await fetch(`${API_BASE}/api/images?limit=10`);
        if (res.ok) {
          const data = await res.json();
          setImages(data);
        }
      } catch (error) {
        console.error("Failed to fetch images:", error);
      }
    };
    fetchImages();
  }, []);

  const generateMutation = useMutation({
    mutationFn: async (promptText: string) => {
      const res = await fetch(`${API_BASE}/api/generate`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: promptText, seed: 12345 }),
      });
      if (!res.ok) throw new Error("Failed to generate");
      const newImage = await res.json();
      // Add new image to the top of the list
      setImages([newImage, ...images]);
      return newImage;
    },
  });

  const copyToClipboard = async (text: string, id: number) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      if (copyTimeoutRef.current) clearTimeout(copyTimeoutRef.current);
      copyTimeoutRef.current = setTimeout(() => setCopiedId(null), 2500);
    } catch (err) {
      console.error("Failed to copy:", err);
    }
  };

  const copyAll = async () => {
    const allCommands = SETUP_STEPS.map(s => s.command).join("\n\n");
    try {
      await navigator.clipboard.writeText(allCommands);
      setCopiedId(999);
      if (copyTimeoutRef.current) clearTimeout(copyTimeoutRef.current);
      copyTimeoutRef.current = setTimeout(() => setCopiedId(null), 2500);
    } catch (err) {
      console.error("Failed to copy all:", err);
    }
  };

  const handleGenerate = () => {
    generateMutation.mutate(prompt);
  };

  const latestImage = images[0];

  return (
    <div className="min-h-screen bg-[#020408] text-zinc-100 font-sans selection:bg-cyan-500/30 pb-24">
      {/* Background Gradients */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-cyan-500/10 blur-[120px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-600/10 blur-[120px] rounded-full" />
      </div>

      <header className="border-b border-white/5 bg-black/40 backdrop-blur-2xl sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-cyan-400 to-blue-600 p-[1px]">
              <div className="h-full w-full rounded-[11px] bg-[#020408] flex items-center justify-center text-cyan-400">
                <Terminal className="w-5 h-5" />
              </div>
            </div>
            <div>
              <h1 className="font-black text-xl tracking-tighter italic uppercase leading-none" data-testid="app-title">NBA_Josh // Drill_AI</h1>
              <p className="text-[10px] text-zinc-500 font-mono tracking-[0.2em] mt-1">SYS_DEEPLINK: AUTOMATED_V2.0</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setShowPromptPanel(!showPromptPanel)}
              data-testid="button-open-generator"
              className="group relative flex items-center gap-2 text-xs font-bold uppercase tracking-widest bg-cyan-500 text-black hover:bg-cyan-400 transition-all px-6 py-3 rounded-full overflow-hidden"
            >
              <Zap className="w-4 h-4" />
              Generate
            </button>
            <button 
              onClick={copyAll}
              data-testid="button-copy-full-script"
              className="group relative flex items-center gap-2 text-xs font-bold uppercase tracking-widest bg-white text-black hover:bg-cyan-400 transition-all px-6 py-3 rounded-full overflow-hidden"
            >
              <div className="relative z-10 flex items-center gap-2">
                {copiedId === 999 ? (
                  <><Check className="w-4 h-4" /> Copied</>
                ) : (
                  <><Copy className="w-4 h-4" /> Full Script</>
                )}
              </div>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 mt-16 grid grid-cols-1 lg:grid-cols-[1fr_340px] gap-16">
        <div className="space-y-12">
          <div className="relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-3xl blur opacity-20 group-hover:opacity-30 transition duration-1000"></div>
            <div className="relative bg-[#090C10] border border-white/5 rounded-3xl p-10">
              <div className="flex items-center gap-3 mb-6">
                <div className="px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-[10px] font-black uppercase tracking-widest text-cyan-400">
                  Headless Ready
                </div>
                <div className="px-3 py-1 rounded-full bg-white/5 border border-white/10 text-[10px] font-black uppercase tracking-widest text-zinc-400">
                  GPU Optimized
                </div>
              </div>
              <h2 className="text-6xl font-black tracking-tighter mb-6 bg-gradient-to-b from-white to-zinc-500 bg-clip-text text-transparent italic leading-[0.9]" data-testid="text-main-heading">
                CORE_ENGINE<br/>DEPLOYMENT
              </h2>
              <p className="text-zinc-400 text-lg max-w-2xl leading-relaxed font-medium">
                Unified environment for <strong>Dark Drill</strong> cinematography. This pipeline automates venv creation, CUDA dependency injection, and SD v1.5 local caching.
              </p>
            </div>
          </div>

          <div className="space-y-6">
            {SETUP_STEPS.map((step, index) => {
              const isActive = activeStep === step.id;
              return (
                <motion.div 
                  key={step.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className={`group relative bg-[#090C10]/60 border transition-all duration-500 rounded-3xl overflow-hidden cursor-pointer ${
                    isActive ? 'border-cyan-500/40 bg-cyan-500/[0.02] shadow-[0_0_50px_-12px_rgba(6,182,212,0.15)] scale-[1.01]' : 'border-white/5 hover:border-white/20'
                  }`}
                  onClick={() => setActiveStep(step.id)}
                  data-testid={`step-card-${step.id}`}
                >
                  <div className="flex items-start gap-6 p-8">
                    <div className={`mt-1 flex-shrink-0 w-12 h-12 rounded-2xl flex items-center justify-center transition-all duration-500 ${
                      isActive ? 'bg-cyan-500 text-black shadow-[0_0_20px_rgba(6,182,212,0.4)]' : 'bg-white/5 text-zinc-500 group-hover:bg-white/10'
                    }`}>
                      <step.icon className="w-6 h-6" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-black text-xl tracking-tight uppercase italic flex items-center gap-3">
                          <span className={`text-[10px] font-mono transition-colors ${isActive ? 'text-cyan-400' : 'text-zinc-700'}`}>0{step.id}</span>
                          {step.title}
                        </h3>
                        {isActive && (
                          <div className="flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse" />
                            <span className="text-[10px] font-black uppercase tracking-widest text-cyan-400">Target Active</span>
                          </div>
                        )}
                      </div>
                      <p className="text-zinc-400 text-sm mb-6 leading-relaxed">
                        {step.description}
                      </p>

                      <div className="relative group/code">
                        <div className="absolute -inset-[1px] bg-gradient-to-r from-cyan-500/20 to-blue-600/20 rounded-2xl opacity-0 group-hover/code:opacity-100 transition-opacity" />
                        <pre 
                          className="relative bg-black/60 border border-white/5 rounded-2xl p-6 overflow-x-auto text-xs font-mono text-cyan-50/70 leading-relaxed scrollbar-hide"
                          data-testid={`code-block-${step.id}`}
                        >
                          <code>{step.command}</code>
                        </pre>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            copyToClipboard(step.command, step.id);
                          }}
                          data-testid={`button-copy-${step.id}`}
                          className="absolute top-4 right-4 p-3 rounded-xl bg-white/5 hover:bg-cyan-500 hover:text-black transition-all border border-white/10 opacity-0 group-hover/code:opacity-100 flex items-center gap-2 backdrop-blur-md"
                        >
                          <span className="text-[10px] font-black uppercase tracking-widest">Copy</span>
                          {copiedId === step.id ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        <aside className="space-y-8">
          <AnimatePresence>
            {showPromptPanel && (
              <motion.div
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                className="fixed top-24 right-6 w-96 max-w-[calc(100vw-24px)] bg-[#090C10] border border-cyan-500/30 rounded-3xl p-6 shadow-2xl shadow-cyan-500/10 z-50"
              >
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-black text-lg uppercase tracking-tight text-cyan-400">Generation Panel</h3>
                  <button onClick={() => setShowPromptPanel(false)} className="text-zinc-600 hover:text-zinc-400">✕</button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="text-[10px] uppercase tracking-widest text-zinc-600 font-black block mb-2">Custom Prompt</label>
                    <textarea
                      value={prompt}
                      onChange={(e) => setPrompt(e.target.value)}
                      data-testid="input-prompt"
                      placeholder="Enter your generation prompt..."
                      className="w-full h-24 bg-black/60 border border-white/10 rounded-2xl p-4 text-sm text-cyan-50/70 placeholder-zinc-700 focus:outline-none focus:border-cyan-500/50 resize-none font-mono"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] uppercase tracking-widest text-zinc-600 font-black block mb-2">Sample Prompts</label>
                    <div className="space-y-2 max-h-48 overflow-y-auto">
                      {SAMPLE_PROMPTS.map((p, idx) => (
                        <button
                          key={idx}
                          onClick={() => setPrompt(p)}
                          data-testid={`button-prompt-${idx}`}
                          className="w-full text-left text-xs p-3 rounded-xl bg-white/5 hover:bg-cyan-500/10 border border-white/5 hover:border-cyan-500/30 text-zinc-400 hover:text-cyan-400 transition-all line-clamp-2"
                        >
                          {p}
                        </button>
                      ))}
                    </div>
                  </div>

                  <button
                    onClick={handleGenerate}
                    disabled={generateMutation.isPending}
                    data-testid="button-generate-image"
                    className="w-full flex items-center justify-center gap-2 p-4 rounded-2xl bg-cyan-500 text-black font-black uppercase tracking-widest text-sm hover:bg-cyan-400 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                  >
                    {generateMutation.isPending ? (
                      <>
                        <span className="animate-spin">⚡</span>
                        Generating with OpenAI...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4" />
                        Generate with OpenAI
                      </>
                    )}
                  </button>
                  {!OPENAI_API_KEY && (
                    <p className="text-[10px] text-yellow-400/70 text-center italic">
                      Add OPENAI_API_KEY to environment for real generations
                    </p>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="bg-[#090C10] border border-white/5 rounded-3xl p-8 shadow-2xl sticky top-28">
            <h3 className="font-black text-[10px] uppercase tracking-[0.3em] text-zinc-500 mb-8 flex items-center justify-between">
              Drill_System_Profile
              <Activity className="w-3 h-3 text-cyan-500" />
            </h3>
            
            <div className="space-y-6">
              <div className="space-y-2">
                <span className="text-[10px] uppercase tracking-widest text-zinc-600 font-black block">Visual Aesthetic</span>
                <div className="p-4 rounded-2xl bg-gradient-to-br from-cyan-500/10 to-blue-600/10 border border-cyan-500/20">
                  <span className="text-sm font-black text-cyan-400 italic uppercase" data-testid="text-aesthetic">Dark Drill / Urban Night</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-4 rounded-2xl bg-white/5 border border-white/5 text-center">
                  <span className="text-[10px] text-zinc-600 block mb-1">Precision</span>
                  <span className="text-xs font-bold text-zinc-300" data-testid="text-precision">FP16</span>
                </div>
                <div className="p-4 rounded-2xl bg-white/5 border border-white/5 text-center">
                  <span className="text-[10px] text-zinc-600 block mb-1">Compute</span>
                  <span className="text-xs font-bold text-zinc-300" data-testid="text-compute">CUDA</span>
                </div>
              </div>

              <div className="h-[1px] bg-white/5" />

              <div className="space-y-3">
                <h4 className="text-[10px] font-black uppercase tracking-widest text-zinc-600">Frame Gallery ({images.length})</h4>
                <AnimatePresence>
                  {latestImage && (
                    <motion.div
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      className="relative group aspect-video rounded-2xl overflow-hidden border border-cyan-500/30 bg-black shadow-lg shadow-cyan-500/10"
                    >
                      <img src={latestImage.imageUrl} alt="Generated" className="w-full h-full object-cover" />
                      <button
                        onClick={() => copyToClipboard(latestImage.prompt, 777)}
                        className="absolute top-2 right-2 p-2 bg-black/60 rounded-lg border border-white/10 text-zinc-400 hover:text-cyan-400 transition-colors"
                      >
                        <Copy className="w-4 h-4" />
                      </button>
                      <div className="absolute bottom-0 left-0 right-0 p-3 bg-gradient-to-t from-black to-transparent">
                        <p className="text-[10px] text-cyan-400 font-mono truncate">{latestImage.prompt}</p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {!latestImage && (
                  <div className="group relative aspect-video rounded-2xl bg-black border border-white/5 flex flex-col items-center justify-center overflow-hidden cursor-pointer hover:border-cyan-500/50 transition-all" data-testid="preview-frame">
                    <Camera className="w-8 h-8 text-zinc-800 group-hover:text-cyan-500 transition-all duration-500" />
                    <span className="text-[10px] font-black uppercase tracking-widest text-zinc-700 mt-2 group-hover:text-cyan-400 transition-all">Frame Preview</span>
                    <div className="absolute inset-0 bg-gradient-to-t from-cyan-500/20 to-transparent opacity-0 group-hover:opacity-100 transition-all" />
                  </div>
                )}
              </div>

              <button 
                className="w-full flex items-center justify-center gap-2 p-4 rounded-2xl bg-white/5 hover:bg-white/10 text-[10px] font-black uppercase tracking-widest text-zinc-400 border border-white/5 transition-all"
                data-testid="button-export-profile"
              >
                <Share2 className="w-3 h-3" />
                Export Profile
              </button>
            </div>
          </div>
        </aside>
      </main>
    </div>
  );
}