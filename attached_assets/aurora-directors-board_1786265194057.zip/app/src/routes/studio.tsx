import { createFileRoute } from "@tanstack/react-router";
import { StudioPage } from "@/features/storyboard/studio/StudioPage";

export const Route = createFileRoute("/studio")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Studio · Storyboard Flow Canvas" },
      {
        name: "description",
        content:
          "Chain shot nodes, generate frames with AI, and export your music video storyboard as a ZIP.",
      },
      { property: "og:title", content: "Studio · Storyboard Flow Canvas" },
      {
        property: "og:description",
        content:
          "Chain shot nodes, generate frames with AI, and export your music video storyboard as a ZIP.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: StudioPage,
});
