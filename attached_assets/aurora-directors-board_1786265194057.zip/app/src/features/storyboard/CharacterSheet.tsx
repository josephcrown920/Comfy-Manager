import { useCallback, useMemo, useState } from "react";
import { streamImage } from "@/lib/streamImage";
import { CHARACTER_LOCK, NEGATIVE_LOCK, STYLE_LOCK } from "./characterLock";
import { loadIdentityReferences, IDENTITY_REFS } from "./identityRefs";
import { useStudio } from "./studioStore";

export type SheetSlot = {
  id: string;
  label: string;
  angle: string;
  image: string | null;
  busy: boolean;
  error?: string;
};

const ANGLES: { id: string; label: string; angle: string }[] = [
  { id: "front", label: "Front", angle: "straight-on front view, eyes to lens" },
  { id: "three-q", label: "3/4 Left", angle: "three-quarter left profile" },
  { id: "profile", label: "Profile", angle: "hard 90° side profile" },
  { id: "back", label: "Back", angle: "from behind, head slightly turned" },
  { id: "low", label: "Low Angle", angle: "low hero angle looking up" },
  { id: "high", label: "High Angle", angle: "high angle looking down" },
  { id: "close", label: "Close Detail", angle: "tight macro on shades, chain and jawline" },
  { id: "full", label: "Full Body", angle: "full-body standing turnaround, feet in frame" },
];

/** Builds the sheet prompt for one angle — identity locked, neutral studio sweep. */
function sheetPrompt(angle: string, seedLine: string) {
  return [
    CHARACTER_LOCK,
    STYLE_LOCK,
    `CHARACTER REFERENCE SHEET PANEL: ${angle}.`,
    "Neutral seamless charcoal studio sweep, soft top key with a cool rim, no props, no text, no logos.",
    "Consistent wardrobe and accessories across every panel of the sheet.",
    seedLine,
    `AVOID: ${NEGATIVE_LOCK}`,
  ]
    .filter(Boolean)
    .join("\n");
}

export function CharacterSheet() {
  const { seedLine, settings } = useStudio();
  const [slots, setSlots] = useState<SheetSlot[]>(() =>
    ANGLES.map((a) => ({ ...a, image: null, busy: false })),
  );
  const [runningAll, setRunningAll] = useState(false);

  const refs = useMemo(
    () => IDENTITY_REFS.map((r) => ({ ...r, image: settings.imageOverrides[r.id] ?? r.url })),
    [settings.imageOverrides],
  );

  const patch = useCallback(
    (id: string, next: Partial<SheetSlot>) =>
      setSlots((prev) => prev.map((s) => (s.id === id ? { ...s, ...next } : s))),
    [],
  );

  const render = useCallback(
    async (slot: SheetSlot) => {
      patch(slot.id, { busy: true, error: undefined });
      try {
        const references = await loadIdentityReferences(refs.map((r) => r.image));
        await streamImage(
          "/api/generate-shot",
          sheetPrompt(slot.angle, seedLine()),
          (dataUrl) => patch(slot.id, { image: dataUrl }),
          references,
          settings.vidModel,
        );
      } catch (err) {
        patch(slot.id, { error: err instanceof Error ? err.message : "Render failed" });
      } finally {
        patch(slot.id, { busy: false });
      }
    },
    [patch, refs, seedLine, settings.vidModel],
  );

  const renderAll = useCallback(async () => {
    setRunningAll(true);
    for (const slot of slots) {
      // eslint-disable-next-line no-await-in-loop
      await render(slot);
    }
    setRunningAll(false);
  }, [render, slots]);

  return (
    <div className="cs-wrap">
      <header className="cs-head">
        <div>
          <span className="cs-kicker">Identity</span>
          <h3 className="cs-title">Character Reference Sheet</h3>
          <p className="cs-sub">
            Eight locked angles from the same avatar — the turnaround every frame is graded against.
          </p>
        </div>
        <div className="cs-head-actions">
          <button
            type="button"
            className="dir-btn dir-btn-primary"
            disabled={runningAll}
            onClick={renderAll}
          >
            {runningAll ? "Rendering sheet…" : "Render full sheet"}
          </button>
        </div>
      </header>

      <div className="cs-refs">
        {refs.map((r) => (
          <figure key={r.id} className="cs-ref">
            <img src={r.image} alt={`Identity reference ${r.label}`} loading="lazy" />
            <figcaption>{r.label}</figcaption>
          </figure>
        ))}
        <p className="cs-ref-note">Locked references — every panel is conditioned on these frames.</p>
      </div>

      <div className="cs-sheet">
        <div className="cs-grid">
          {slots.map((slot, i) => (
            <figure key={slot.id} className={`cs-cell ${slot.busy ? "cs-cell-busy" : ""}`}>
              <div className="cs-cell-media">
                {slot.image ? (
                  <img src={slot.image} alt={`${slot.label} turnaround panel`} />
                ) : (
                  <span className="cs-cell-empty">{slot.label}</span>
                )}
                {slot.busy && <span className="cs-scan" aria-hidden />}
                <span className="cs-cell-index">{String(i + 1).padStart(2, "0")}</span>
                <figcaption className="cs-cell-foot">
                  <span className="cs-cell-label">{slot.label}</span>
                  <button
                    type="button"
                    className="dir-mini-btn"
                    disabled={slot.busy || runningAll}
                    onClick={() => render(slot)}
                  >
                    {slot.image ? "Redo" : "Render"}
                  </button>
                </figcaption>
                {slot.error && <p className="cs-err">{slot.error}</p>}
              </div>
            </figure>
          ))}
        </div>
      </div>

    </div>
  );
}
