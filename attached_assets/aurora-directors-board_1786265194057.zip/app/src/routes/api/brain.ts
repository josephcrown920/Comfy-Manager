import { createFileRoute } from "@tanstack/react-router";

type Task = "shot-prompts" | "flow-fill" | "moodboard-expand";

const SCHEMAS: Record<Task, { name: string; schema: Record<string, unknown> }> = {
  "shot-prompts": {
    name: "shot_prompts",
    schema: {
      type: "object",
      additionalProperties: false,
      required: ["shots"],
      properties: {
        shots: {
          type: "array",
          items: {
            type: "object",
            additionalProperties: false,
            required: ["id", "title", "camera", "prompt", "negative", "continuity"],
            properties: {
              id: { type: "string" },
              title: { type: "string" },
              camera: { type: "string" },
              prompt: { type: "string" },
              negative: { type: "string" },
              continuity: { type: "string" },
            },
          },
        },
      },
    },
  },
  "flow-fill": {
    name: "flow_fill",
    schema: {
      type: "object",
      additionalProperties: false,
      required: ["nodes"],
      properties: {
        nodes: {
          type: "array",
          items: {
            type: "object",
            additionalProperties: false,
            required: ["id", "text", "rows"],
            properties: {
              id: { type: "string" },
              text: { type: "string" },
              rows: {
                type: ["array", "null"],
                items: { type: "string" },
              },
            },
          },
        },
      },
    },
  },
  "moodboard-expand": {
    name: "moodboard_expand",
    schema: {
      type: "object",
      additionalProperties: false,
      required: ["setups"],
      properties: {
        setups: {
          type: "array",
          items: {
            type: "object",
            additionalProperties: false,
            required: ["id", "label", "scene", "camera", "wardrobe", "continuity", "prompt"],
            properties: {
              id: { type: "string" },
              label: { type: "string" },
              scene: { type: "string" },
              camera: { type: "string" },
              wardrobe: { type: "string" },
              continuity: { type: "string" },
              prompt: { type: "string" },
            },
          },
        },
      },
    },
  },
};

const SYSTEM = [
  "You are the creative brain of a music-video storyboard tool.",
  "The subject is a fixed, identity-locked avatar; never change the person, only scene, wardrobe, camera and lighting.",
  "Write dense, production-ready image/video prompts in the cinematic neon-noir language of the deck",
  "(neon red, royal blue, hot pink, gold on near-black; anamorphic 35mm; photoreal; 16:9).",
  "Keep every prompt under 900 characters. Never include text, logos or watermarks in the described frame.",
].join(" ");

export const Route = createFileRoute("/api/brain")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const body = (await request.json()) as { task?: Task; input?: unknown; model?: string };
        const task = body.task;
        if (!task || !(task in SCHEMAS)) {
          return new Response("Unknown task", { status: 400 });
        }

        const key = process.env.LOVABLE_API_KEY;
        if (!key) return new Response("Missing LOVABLE_API_KEY", { status: 500 });

        const { name, schema } = SCHEMAS[task];

        const RESPONSES_MODELS = ["openai/gpt-5.6-sol", "openai/gpt-5.6-terra"];
        const CHAT_MODELS = ["google/gemini-3.6-flash", "google/gemini-3.1-pro-preview"];
        const requested = typeof body.model === "string" ? body.model : "";
        const model =
          RESPONSES_MODELS.includes(requested) || CHAT_MODELS.includes(requested)
            ? requested
            : RESPONSES_MODELS[0];
        const userText = `TASK: ${task}\n\nCONTEXT (json):\n${JSON.stringify(body.input ?? {}, null, 2)}`;

        // Gemini brains go through chat completions (non-streaming, schema-constrained).
        if (CHAT_MODELS.includes(model)) {
          const chat = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${key}`,
            },
            body: JSON.stringify({
              model,
              messages: [
                { role: "system", content: SYSTEM },
                { role: "user", content: userText },
              ],
              response_format: { type: "json_schema", json_schema: { name, schema } },
            }),
          });
          if (!chat.ok) {
            const detail = await chat.text().catch(() => "");
            return new Response(detail || "Brain call failed", { status: chat.status || 500 });
          }
          const json = (await chat.json()) as {
            choices?: { message?: { content?: string } }[];
          };
          const content = json.choices?.[0]?.message?.content ?? "";
          try {
            return Response.json(JSON.parse(content));
          } catch {
            return new Response("Brain returned malformed JSON", { status: 502 });
          }
        }

        const upstream = await fetch("https://ai.gateway.lovable.dev/v1/responses", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Lovable-API-Key": key,
            "X-Lovable-AIG-SDK": "fetch",
          },
          body: JSON.stringify({
            model,
            stream: true,
            store: false,
            instructions: SYSTEM,
            input: [
              {
                role: "user",
                content: [{ type: "input_text", text: userText }],
              },
            ],
            reasoning: { effort: "low", summary: "auto" },
            text: {
              format: { type: "json_schema", name, schema, strict: true },
            },
          }),
        });


        if (!upstream.ok || !upstream.body) {
          const detail = await upstream.text().catch(() => "");
          return new Response(detail || "Brain call failed", { status: upstream.status || 500 });
        }

        // Consume the SSE stream server-side and return the final JSON payload.
        const reader = upstream.body.pipeThrough(new TextDecoderStream()).getReader();
        let buffer = "";
        let text = "";
        let errorMessage = "";

        const handleEvent = (chunk: string) => {
          const dataLines = chunk
            .split("\n")
            .filter((l) => l.startsWith("data:"))
            .map((l) => l.slice(5).trim());
          if (!dataLines.length) return;
          const raw = dataLines.join("\n");
          if (raw === "[DONE]") return;
          try {
            const evt = JSON.parse(raw) as {
              type?: string;
              delta?: string;
              response?: { output_text?: string };
              error?: { message?: string };
            };
            if (evt.type === "response.output_text.delta" && typeof evt.delta === "string") {
              text += evt.delta;
            } else if (evt.type === "response.completed" && evt.response?.output_text) {
              text = evt.response.output_text;
            } else if (evt.type === "error" || evt.error) {
              errorMessage = evt.error?.message ?? "Brain stream error";
            }
          } catch {
            /* ignore keepalives */
          }
        };

        while (true) {
          const { value, done } = await reader.read();
          if (done) break;
          buffer += value;
          let idx = buffer.indexOf("\n\n");
          while (idx !== -1) {
            handleEvent(buffer.slice(0, idx));
            buffer = buffer.slice(idx + 2);
            idx = buffer.indexOf("\n\n");
          }
        }
        if (buffer.trim()) handleEvent(buffer);

        if (errorMessage) return new Response(errorMessage, { status: 502 });
        if (!text.trim()) return new Response("Brain returned no content", { status: 502 });

        try {
          return Response.json(JSON.parse(text));
        } catch {
          return new Response("Brain returned malformed JSON", { status: 502 });
        }
      },
    },
  },
});
