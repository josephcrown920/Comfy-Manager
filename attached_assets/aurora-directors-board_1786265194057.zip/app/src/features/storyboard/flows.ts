import { CHARACTER_LOCK, STYLE_LOCK } from "./characterLock";

export type FlowNodeKind =
  | "prompt"
  | "image"
  | "iterator"
  | "audio"
  | "model"
  | "output";

export type FlowNode = {
  id: string;
  kind: FlowNodeKind;
  title: string;
  /** prefilled, editable prompt text */
  text?: string;
  /** list rows for iterator nodes (prefilled) */
  rows?: string[];
  /** meta chips shown under model/output nodes */
  meta?: string[];
  /** default demo image slot key — resolved against the moodboard */
  demo?: number;
};

export type Flow = {
  id: string;
  label: string;
  tags: ("IMAGE" | "VIDEO" | "CAMPAIGN" | "BATCH" | "MOODBOARD")[];
  blurb: string;
  /** what the user gets, in plain words */
  outcome: string;
  /** "image" flows can actually run against the AI image endpoint */
  runnable: boolean;
  /** "preview" flows hand off to the rendered preview tab */
  handoff?: "preview";
  nodes: FlowNode[];
};

const LOCK = `${CHARACTER_LOCK}\n\n${STYLE_LOCK}`;

export const FLOWS: Flow[] = [
  {
    id: "grid-extract",
    label: "Grid extraction and iteration",
    tags: ["IMAGE", "BATCH"],
    blurb: "Extract individual shots from a generated image grid and iterate on each separately.",
    outcome: "Four new deck frames from one reference grid — same face, same palette, four setups.",
    runnable: true,
    nodes: [
      {
        id: "img",
        kind: "image",
        title: "Image Upload",
        demo: 0,
      },
      {
        id: "iter",
        kind: "iterator",
        title: "Text Iterator",
        rows: [
          "extract cell 1,1 — rebuild as an extreme close-up on the red sculpted shades, neon red rim light",
          "extract cell 1,2 — rebuild as a low-angle hero shot, wet asphalt reflections, royal blue haze",
          "extract cell 2,1 — rebuild as a medium chest-up profile, hot pink backdrop, stage haze",
          "extract cell 2,2 — rebuild as a wide establishing shot, alley steam, gold practical lights",
        ],
      },
      {
        id: "model",
        kind: "model",
        title: "Nano Banana Pro (image)",
        text: `${LOCK}\n\nTASK: Re-render the referenced grid cell as a standalone 16:9 cinematic still. Keep wardrobe and lighting continuity with the rest of the deck.`,
        meta: ["1K", "16:9", "x4"],
      },
      { id: "out", kind: "output", title: "New deck frames", meta: ["4 images", "adds to Shot Deck"] },
    ],
  },
  {
    id: "multicam",
    label: "Multi-camera audio scene",
    tags: ["VIDEO", "MOODBOARD"],
    blurb: "Generate the same audio-driven scene from multiple reference angles simultaneously.",
    outcome: "One bar of your track covered from 4 angles so you can cut between them in edit.",
    runnable: true,
    handoff: "preview",
    nodes: [
      {
        id: "prompt",
        kind: "prompt",
        title: "Prompt",
        text: `${LOCK}\n\nARTIST is performing directly to camera, lip movements precisely synced to the audio track. Handheld micro-drift, neon practicals flickering on the beat. Keep the same wardrobe across every angle.`,
      },
      { id: "iter", kind: "iterator", title: "Image Iterator (angles)", demo: 1 },
      { id: "audio", kind: "audio", title: "Audio Upload", text: "Your loaded track — the stamped section is used as the scene bed." },
      { id: "model", kind: "model", title: "Audio to Video", meta: ["16:9", "x4 angles"] },
    ],
  },
  {
    id: "chained",
    label: "Chained video generation",
    tags: ["VIDEO"],
    blurb: "Use the last frame of one video as the start of the next, creating a seamless continuous scene.",
    outcome: "Shots 01 → 10 stitched into one unbroken camera move for the full preview render.",
    runnable: false,
    handoff: "preview",
    nodes: [
      {
        id: "prompt",
        kind: "prompt",
        title: "Prompt",
        text: `${LOCK}\n\nContinuous one-take camera move: start on the stamped frame, push in, whip to the next location without a cut. Motion blur through transitions, neon streaks trailing the move.`,
      },
      { id: "img", kind: "image", title: "Image Upload (start frame)", demo: 2 },
      { id: "m1", kind: "model", title: "Clip A", meta: ["4s", "1080p", "16:9"] },
      { id: "ex1", kind: "output", title: "Extract Frame", meta: ["Last Frame"] },
      { id: "m2", kind: "model", title: "Clip B", meta: ["4s", "1080p", "16:9"] },
      { id: "out", kind: "output", title: "Stitched preview", meta: ["Opens in Preview tab"] },
    ],
  },
  {
    id: "campaign",
    label: "Image to campaign video",
    tags: ["VIDEO", "CAMPAIGN"],
    blurb: "Turn a product image into a lifestyle scene and animate it into a video.",
    outcome: "Your sneaker/jacket drop shot as a lifestyle beat with the artist wearing it.",
    runnable: true,
    nodes: [
      {
        id: "prompt",
        kind: "prompt",
        title: "Prompt",
        text: `${LOCK}\n\nPRODUCT HERO: place the uploaded product (jacket / sneaker) on the artist in a lifestyle scene — courtside dusk, wet neon street or backstage corridor. Product stays crisp and readable in frame, artist identity unchanged.`,
      },
      { id: "img", kind: "image", title: "Product Image Upload", demo: 3 },
      {
        id: "iter",
        kind: "iterator",
        title: "Text Iterator (copy beats)",
        rows: [
          'artist says "this the one they been waiting on"',
          'artist says "drop lands friday, don\'t sleep"',
        ],
      },
      { id: "model", kind: "model", title: "Image to Video", meta: ["4s", "1080p", "16:9"] },
    ],
  },
  {
    id: "moodboard-expand",
    label: "Moodboard expansion",
    tags: ["IMAGE", "MOODBOARD"],
    blurb: "Pull palette, wardrobe and character locks from the moodboard into brand-new frames.",
    outcome: "Fresh frames that inherit every moodboard rule without you rewriting the prompt.",
    runnable: true,
    nodes: [
      { id: "img", kind: "image", title: "Moodboard Reference", demo: 4 },
      {
        id: "prompt",
        kind: "prompt",
        title: "Prompt",
        text: `${LOCK}\n\nDIRECTION: New setup not yet in the deck — rooftop helipad at blue hour, red smoke flare, artist walking toward camera. Inherit the moodboard palette exactly: neon red, royal blue, hot pink, gold on near-black.`,
      },
      { id: "model", kind: "model", title: "Nano Banana Pro (image)", meta: ["1K", "16:9"] },
      { id: "out", kind: "output", title: "Add to deck", meta: ["1 image"] },
    ],
  },
  {
    id: "dubbing",
    label: "Multi-market dubbing",
    tags: ["VIDEO", "CAMPAIGN"],
    blurb: "Produce dubbed versions of a performance clip for different markets.",
    outcome: "Same performance frame, three language versions for rollout.",
    runnable: false,
    nodes: [
      { id: "img", kind: "image", title: "Video / Frame Upload", demo: 5 },
      { id: "d1", kind: "model", title: "Dubbing", meta: ["Spanish", "Lip-sync On"] },
      { id: "d2", kind: "model", title: "Dubbing", meta: ["French", "Lip-sync On"] },
      { id: "d3", kind: "model", title: "Dubbing", meta: ["German", "Lip-sync On"] },
    ],
  },
];
