CREATE TABLE public.gpu_workers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  gpu TEXT,
  models TEXT[] NOT NULL DEFAULT '{}',
  status TEXT NOT NULL DEFAULT 'offline',
  last_seen_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.gpu_workers TO anon, authenticated;
GRANT ALL ON public.gpu_workers TO service_role;
ALTER TABLE public.gpu_workers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "gpu_workers_public_read" ON public.gpu_workers FOR SELECT TO anon, authenticated USING (true);

CREATE TABLE public.render_jobs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  board_id TEXT,
  shot_id TEXT,
  kind TEXT NOT NULL DEFAULT 'video',
  model TEXT NOT NULL,
  prompt TEXT NOT NULL,
  input_image_url TEXT,
  params JSONB NOT NULL DEFAULT '{}'::jsonb,
  status TEXT NOT NULL DEFAULT 'queued',
  output_url TEXT,
  error TEXT,
  worker_id UUID REFERENCES public.gpu_workers(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.render_jobs TO anon, authenticated;
GRANT ALL ON public.render_jobs TO service_role;
ALTER TABLE public.render_jobs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "render_jobs_public_read" ON public.render_jobs FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "render_jobs_public_insert" ON public.render_jobs FOR INSERT TO anon, authenticated WITH CHECK (status = 'queued' AND worker_id IS NULL AND output_url IS NULL);
CREATE INDEX render_jobs_status_created_idx ON public.render_jobs(status, created_at);

CREATE OR REPLACE FUNCTION public.set_render_jobs_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;
REVOKE EXECUTE ON FUNCTION public.set_render_jobs_updated_at() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER render_jobs_set_updated BEFORE UPDATE ON public.render_jobs
  FOR EACH ROW EXECUTE FUNCTION public.set_render_jobs_updated_at();