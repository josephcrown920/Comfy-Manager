import comfyui
import os

os.environ["COMFYUI_MODELS_DIR"] = "./models"
os.environ["COMFYUI_OUTPUT_DIR"] = "./outputs"

# Run web UI automatically without prompts
comfyui.launch(ui="web", port=7860, gpu=True)
