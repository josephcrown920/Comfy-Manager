import { shots } from "./shots";

/**
 * Canonical identity frames. These are sent to the model as visual references
 * on every generation so the face, hair, shades and jewellery stay identical.
 */
export const IDENTITY_REF_IDS = ["03", "02", "08"] as const;

export type IdentityRef = { id: string; label: string; url: string };

export const IDENTITY_REFS: IdentityRef[] = IDENTITY_REF_IDS.map((id) => {
  const shot = shots.find((s) => s.id === id)!;
  return { id, label: shot.title, url: shot.image };
});

export type LockStrength = "strict" | "balanced" | "loose";

export const LOCK_STRENGTHS: { id: LockStrength; label: string; hint: string }[] = [
  { id: "strict", label: "Strict identity", hint: "Face, hair and eyewear must match the references exactly" },
  { id: "balanced", label: "Balanced", hint: "Identity locked, wardrobe and scene free to change" },
  { id: "loose", label: "Loose", hint: "Same person, looser interpretation of styling" },
];

const cache = new Map<string, string>();

async function toDataUrl(url: string): Promise<string> {
  const hit = cache.get(url);
  if (hit) return hit;
  const res = await fetch(url);
  const blob = await res.blob();
  const dataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Could not read reference frame"));
    reader.readAsDataURL(blob);
  });
  cache.set(url, dataUrl);
  return dataUrl;
}

/** Loads the locked reference frames as data URLs for multimodal conditioning. */
export async function loadIdentityReferences(urls: string[] = IDENTITY_REFS.map((r) => r.url)) {
  const out: string[] = [];
  for (const url of urls) {
    try {
      out.push(await toDataUrl(url));
    } catch {
      /* skip unreachable reference */
    }
  }
  return out;
}
